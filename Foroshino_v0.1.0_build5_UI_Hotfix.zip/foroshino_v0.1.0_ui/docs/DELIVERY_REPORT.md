# گزارش تحویل فروشینو ۰.۱.۰ — Build 5

## وضعیت نسخه

- نام: فروشینو / Foroshino
- نسخه Flutter: `0.1.0+5`
- محدوده: UI/UX نهایی و جریان‌های بصری Version 0.1
- Backend: ندارد
- پایگاه داده تجاری: ندارد
- عملیات واقعی مالی و موجودی: طبق برنامه نسخه‌بندی غیرفعال است

## پوشش تحویل

- ۵ بخش ناوبری اصلی
- ۵۰ مسیر تعریف‌شده
- رابط فارسی RTL
- حالت روشن و تاریک
- طراحی واکنش‌گرا برای گوشی و تبلت
- پنل مدیریت کل مخفی با مسیر هفت‌لمسی
- حالت‌های خالی، بارگذاری، آفلاین، هشدار، موفقیت و خطا
- جریان‌های بصری خرید، مرجوعی، پرداخت مشتری، موجودی، دستگاه و چاپگر

## اصلاحات نسبت به Build 2

- رفع Overflow صفحه راه‌اندازی فروشگاه در عرض ۳۲۰ پیکسل
- تطبیقی‌شدن دکمه‌های مرحله قبل و ادامه
- رفع تداخل Hero tag دکمه‌های شناور در StatefulShell
- جایگزینی API منسوخ‌شده Dropdown با `initialValue`
- حفظ کامل تست‌های رندر گوشی کوچک و تبلت

## کنترل‌های انجام‌شده در محیط تحویل

- Static validator: موفق
- Parse فایل‌های XML: موفق
- Parse فایل‌های YAML: موفق
- بررسی importهای نسبی: موفق
- بررسی ۵۰ مسیر و ۵۹ ارجاع ناوبری: موفق
- بررسی سلامت ZIP: پس از بسته‌بندی اجرا می‌شود

## کنترل‌های وابسته به Flutter SDK

Workflow مستقل همراه تحویل، مراحل زیر را روی Flutter Stable انجام می‌دهد:

- `flutter analyze`
- `flutter test --concurrency=1`
- ساخت APK Release بازار
- ساخت APK Release مایکت
- کنترل وجود دقیقاً دو APK
- ثبت و آپلود لاگ کامل در صورت شکست
- حذف Artifactهای APK قبلی فقط پس از موفقیت خروجی جدید

تأیید نهایی Build، Test و APK به اجرای بعدی GitHub Actions وابسته است.

## Build 5 correction

The final known small-phone issue from run 7 was isolated to the new-product form. The category dropdown, paired fields, tab strip, and footer actions are now responsive at 320 logical pixels. CI confirmation is pending the next workflow run.
