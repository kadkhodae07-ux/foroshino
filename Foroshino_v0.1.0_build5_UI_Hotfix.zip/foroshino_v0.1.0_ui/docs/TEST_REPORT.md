# گزارش تست نسخه ۰.۱.۰ — Build 4

## تست‌های تعریف‌شده

1. Smoke Test صفحه معرفی و نام فروشینو
2. تست انتخاب حالت تاریک از Riverpod
3. تست لمس هفت‌باره نسخه و بازشدن صفحه احراز هویت مدیر
4. تست رندر تمام مسیرهای UI روی نمایشگر `320×640`
5. تست مسیرهای اصلی روی نمایشگر تبلت `1024×800`
6. تست اختیاری تولید مجموعه تصاویر بازبینی
7. Analyze، Test و ساخت دو APK Release در GitHub Actions

## نتیجه اجرای GitHub Actions شماره ۳

- `flutter analyze`: اجرا شد و خطای Error یا Warning نداشت؛ فقط پیام‌های Info گزارش شد.
- Smoke Test، Dark Mode، Admin Unlock و Screenshot gate: موفق شدند.
- تست مسیرهای UI دو ایراد واقعی را شناسایی کرد:
  - Overflow صفحه `/store-setup` در اندازه `320×640`
  - تداخل Hero tag دکمه‌های شناور هنگام ورود به `/admin`

## اصلاحات Build 4

- Dropdownهای راه‌اندازی فروشگاه در عرض کم به حالت Expandable تغییر کردند.
- نوار عملیات پایین صفحه راه‌اندازی برای عرض‌های کم تطبیقی شد.
- تمام Floating Action Buttonهای باقی‌مانده در StatefulShell دارای Hero tag یکتا شدند.
- تست‌ها حذف، Skip یا ضعیف نشده‌اند.

## بررسی‌های محلی Build 4

- Static validator: موفق
- ۱۷ فایل Dart و ۶۹۴۸ خط سورس/تست
- ۵۰ مسیر تعریف‌شده و ۵۹ ارجاع مسیر بررسی‌شده
- Parse فایل‌های XML و YAML: موفق
- سلامت importهای نسبی و ساختار پروژه: موفق

## وضعیت نهایی

Flutter SDK در محیط بسته‌بندی محلی نصب نیست؛ بنابراین تأیید نهایی اصلاحات Build 4 با اجرای Workflow بعدی انجام می‌شود. تا آن زمان وضعیت Analyze/Test/APK نسخه Build 4 «در انتظار CI» است.


## Run 5 diagnosis and Build 4 correction

GitHub Actions run 5 reached the Flutter test stage. All tests except the 320×640 `/sales` route test passed. Build 4 corrects both reported vertical overflows while retaining the same test coverage. Final Flutter execution remains delegated to GitHub Actions because Flutter SDK is unavailable in the packaging environment.

## Run 7 diagnosis and Build 5 correction

GitHub Actions run 7 reached the Flutter test stage. The tablet route test, onboarding smoke test, screenshot capture test, hidden-admin unlock test, and dark-mode test passed. The only failure was a 284-pixel horizontal `RenderFlex` overflow on `/products/new` at 320×640. Build 5 corrects the narrow product form while retaining the same full route test coverage. Final Flutter execution remains delegated to GitHub Actions because Flutter SDK is unavailable in the packaging environment.

The 23 non-fatal analyzer Info findings included in run 7 were also corrected in source. CI must confirm the resulting `flutter analyze` output because the local packaging environment has no Flutter SDK.
