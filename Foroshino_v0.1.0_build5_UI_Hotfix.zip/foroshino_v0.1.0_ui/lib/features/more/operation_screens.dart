import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../app/widgets.dart';

class StockOperationScreen extends StatelessWidget {
  const StockOperationScreen({super.key, required this.operationType});

  final String operationType;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(operationType)),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            const AppCard(
              child: Column(
                children: [
                  LabeledField(
                    label: 'محصول یا تنوع',
                    hint: 'جست‌وجو یا اسکن بارکد',
                    icon: Icons.inventory_2_outlined,
                  ),
                  SizedBox(height: 14),
                  LabeledField(
                    label: 'تعداد',
                    hint: '۰',
                    icon: Icons.numbers_rounded,
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 14),
                  LabeledField(
                    label: 'دلیل یا مرجع',
                    hint: 'توضیح قابل پیگیری',
                    icon: Icons.link_rounded,
                  ),
                  SizedBox(height: 14),
                  LabeledField(
                    label: 'یادداشت',
                    hint: 'اختیاری',
                    icon: Icons.notes_rounded,
                    maxLines: 3,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader(title: 'پیش‌نمایش تغییر موجودی'),
                  const SizedBox(height: 12),
                  const _DataLine(label: 'موجودی قبل', value: '—'),
                  const _DataLine(label: 'مقدار تغییر', value: '—'),
                  const _DataLine(label: 'موجودی بعد', value: '—'),
                  const SizedBox(height: 8),
                  Text(
                    'موجودی واقعی فقط در یک تراکنش اتمیک و پس از اعتبارسنجی تغییر می‌کند.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: operationType,
                  description:
                      'در نسخه ۰.۱ هیچ تراکنش موجودی ایجاد نمی‌شود. موتور تراکنش در نسخه ۰.۳ فعال خواهد شد.',
                ),
                child: const Text('بررسی و ثبت عملیات'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PurchaseInvoiceScreen extends StatelessWidget {
  const PurchaseInvoiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('فاکتور خرید جدید')),
      body: PageFrame(
        maxWidth: 900,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            AppCard(
              child: Column(
                children: [
                  const LabeledField(
                    label: 'تأمین‌کننده',
                    hint: 'انتخاب تأمین‌کننده',
                    icon: Icons.local_shipping_outlined,
                  ),
                  const SizedBox(height: 14),
                  LayoutBuilder(
                    builder: (context, constraints) {
                      const numberField = LabeledField(
                        label: 'شماره فاکتور خرید',
                        icon: Icons.numbers_rounded,
                      );
                      const dateField = LabeledField(
                        label: 'تاریخ خرید',
                        icon: Icons.event_outlined,
                      );
                      if (constraints.maxWidth < 560) {
                        return const Column(
                          children: [numberField, SizedBox(height: 14), dateField],
                        );
                      }
                      return const Row(
                        children: [
                          Expanded(child: numberField),
                          SizedBox(width: 12),
                          Expanded(child: dateField),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const SectionHeader(title: 'اقلام خرید'),
            const SizedBox(height: 10),
            const EmptyState(
              icon: Icons.shopping_cart_checkout_outlined,
              title: 'قلمی به فاکتور خرید اضافه نشده است',
              message:
                  'هر ردیف شامل محصول، تنوع، تعداد، قیمت خرید و تخفیف خواهد بود.',
            ),
            const SizedBox(height: 14),
            const AppCard(
              child: Column(
                children: [
                  _DataLine(label: 'جمع فاکتور', value: '۰ تومان'),
                  _DataLine(label: 'پرداخت‌شده', value: '۰ تومان'),
                  _DataLine(label: 'بدهی تأمین‌کننده', value: '۰ تومان'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: 'ثبت فاکتور خرید',
                  description:
                      'ثبت خرید، ورود موجودی و بدهی تأمین‌کننده در نسخه ۰.۴ به‌صورت اتمیک فعال می‌شود.',
                ),
                child: const Text('بررسی و ثبت فاکتور خرید'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ReturnFormScreen extends StatefulWidget {
  const ReturnFormScreen({super.key});

  @override
  State<ReturnFormScreen> createState() => _ReturnFormScreenState();
}

class _ReturnFormScreenState extends State<ReturnFormScreen> {
  int type = 0;
  bool damaged = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ثبت مرجوعی')),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('مرجوعی فروش')),
                  ButtonSegment(value: 1, label: Text('مرجوعی سفارش')),
                  ButtonSegment(value: 2, label: Text('مرجوعی تأمین‌کننده')),
                ],
                selected: {type},
                onSelectionChanged: (value) => setState(() => type = value.first),
              ),
            ),
            const SizedBox(height: 14),
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            AppCard(
              child: Column(
                children: [
                  const LabeledField(
                    label: 'فاکتور یا سفارش مرجع',
                    hint: 'جست‌وجوی شماره مرجع',
                    icon: Icons.receipt_long_outlined,
                  ),
                  const SizedBox(height: 14),
                  const LabeledField(
                    label: 'دلیل مرجوعی',
                    hint: 'انتخاب یا توضیح دلیل',
                    icon: Icons.help_outline_rounded,
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: damaged,
                    onChanged: (value) => setState(() => damaged = value),
                    title: const Text('کالا آسیب‌دیده است'),
                    subtitle: const Text('کالای آسیب‌دیده به موجودی قابل فروش بازنمی‌گردد'),
                  ),
                  const LabeledField(
                    label: 'روش جبران',
                    hint: 'بازپرداخت، اعتبار فروشگاه یا تعویض',
                    icon: Icons.currency_exchange_rounded,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const EmptyState(
              icon: Icons.assignment_return_outlined,
              title: 'قلم مرجوعی انتخاب نشده است',
              message: 'مرجوعی کامل یا بخشی از اقلام مرجع قابل انتخاب خواهد بود.',
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: 'ثبت مرجوعی',
                  description:
                      'در نسخه ۰.۱ موجودی، پرداخت یا اعتبار فروشگاه تغییر نمی‌کند. منطق مرجوعی در نسخه ۰.۴ فعال می‌شود.',
                ),
                child: const Text('بررسی و ثبت مرجوعی'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CustomerPaymentScreen extends StatelessWidget {
  const CustomerPaymentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ثبت پرداخت مشتری')),
      body: PageFrame(
        maxWidth: 760,
        child: Column(
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            const AppCard(
              child: Column(
                children: [
                  LabeledField(
                    label: 'مشتری',
                    hint: 'انتخاب مشتری',
                    icon: Icons.person_outline_rounded,
                  ),
                  SizedBox(height: 14),
                  LabeledField(
                    label: 'مبلغ پرداخت',
                    hint: '۰',
                    icon: Icons.payments_outlined,
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 14),
                  LabeledField(
                    label: 'روش پرداخت',
                    hint: 'نقدی، کارت، انتقال بانکی',
                    icon: Icons.credit_card_outlined,
                  ),
                  SizedBox(height: 14),
                  LabeledField(
                    label: 'یادداشت یا شماره پیگیری',
                    icon: Icons.notes_rounded,
                    maxLines: 2,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const AppCard(
              child: Column(
                children: [
                  _DataLine(label: 'بدهی فعلی', value: '—'),
                  _DataLine(label: 'پرداخت', value: '—'),
                  _DataLine(label: 'مانده جدید', value: '—'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: 'ثبت پرداخت مشتری',
                  description:
                      'در نسخه ۰.۱ دفتر مشتری و مانده بدهی تغییر نمی‌کند. این عملیات در نسخه ۰.۳ فعال می‌شود.',
                ),
                child: const Text('بررسی و ثبت پرداخت'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ExpenseDetailsScreen extends StatelessWidget {
  const ExpenseDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('جزئیات هزینه'),
        actions: [
          IconButton(
            onPressed: () => context.push('/expenses/new'),
            icon: const Icon(Icons.edit_outlined),
          ),
          IconButton(
            onPressed: () => _confirmDelete(context),
            icon: const Icon(Icons.delete_outline_rounded),
          ),
        ],
      ),
      body: const PageFrame(
        maxWidth: 760,
        child: Column(
          children: [
            PreviewBanner(compact: true),
            SizedBox(height: 14),
            AppCard(
              child: Column(
                children: [
                  _DataLine(label: 'عنوان', value: '—'),
                  _DataLine(label: 'مبلغ', value: '—'),
                  _DataLine(label: 'دسته‌بندی', value: '—'),
                  _DataLine(label: 'تاریخ', value: '—'),
                  _DataLine(label: 'روش پرداخت', value: '—'),
                  _DataLine(label: 'تکرارشونده', value: '—'),
                ],
              ),
            ),
            SizedBox(height: 14),
            EmptyState(
              icon: Icons.image_outlined,
              title: 'تصویر رسید وجود ندارد',
              message: 'رسید واقعی هزینه پس از ثبت امن فایل در این قسمت نمایش داده می‌شود.',
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.delete_forever_outlined),
        title: const Text('حذف هزینه'),
        content: const Text(
          'حذف عملیات مالی در نسخه نهایی فقط با مجوز مناسب و ثبت Audit Log انجام می‌شود. در نسخه ۰.۱ چیزی حذف نمی‌شود.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
        ],
      ),
    );
  }
}

class ConnectedDevicesScreen extends StatelessWidget {
  const ConnectedDevicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دستگاه‌های متصل')),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            const EmptyState(
              icon: Icons.devices_outlined,
              title: 'دستگاهی ثبت نشده است',
              message:
                  'نام دستگاه، نسخه برنامه، آخرین فعالیت، وضعیت همگام‌سازی و خروج از راه دور اینجا نمایش داده می‌شود.',
            ),
            const SizedBox(height: 14),
            AppCard(
              child: Column(
                children: [
                  const ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(child: Icon(Icons.phone_android_rounded)),
                    title: Text('ساختار کارت دستگاه فعلی'),
                    subtitle: Text('بدون شناسه یا اطلاعات ساختگی'),
                    trailing: Icon(Icons.shield_outlined),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => showPreviewActionSheet(
                        context,
                        title: 'لغو دسترسی دستگاه',
                        description:
                            'خروج از راه دور پس از احراز هویت و تأیید سمت سرور در نسخه ۰.۶ فعال می‌شود.',
                      ),
                      child: const Text('لغو دسترسی'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PrinterSetupScreen extends StatefulWidget {
  const PrinterSetupScreen({super.key});

  @override
  State<PrinterSetupScreen> createState() => _PrinterSetupScreenState();
}

class _PrinterSetupScreenState extends State<PrinterSetupScreen> {
  int type = 0;
  double width = 80;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیم چاپگر')),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SegmentedButton<int>(
                      segments: const [
                        ButtonSegment(value: 0, label: Text('سیستمی / A4')),
                        ButtonSegment(value: 1, label: Text('حرارتی بلوتوث')),
                        ButtonSegment(value: 2, label: Text('لیبل بارکد')),
                      ],
                      selected: {type},
                      onSelectionChanged: (value) => setState(() => type = value.first),
                    ),
                  ),
                  const SizedBox(height: 18),
                  const LabeledField(
                    label: 'چاپگر انتخاب‌شده',
                    hint: 'هنوز چاپگری پیکربندی نشده است',
                    icon: Icons.print_outlined,
                    enabled: false,
                  ),
                  const SizedBox(height: 16),
                  Text('عرض کاغذ: ${width.toInt()} میلی‌متر'),
                  Slider(
                    value: width,
                    min: 40,
                    max: 110,
                    divisions: 14,
                    onChanged: (value) => setState(() => width = value),
                  ),
                  const LabeledField(
                    label: 'حاشیه چاپ',
                    hint: 'میلی‌متر',
                    icon: Icons.padding_rounded,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: 'آزمایش چاپگر',
                  description:
                      'در نسخه ۰.۱ هیچ موفقیت چاپی شبیه‌سازی نمی‌شود. اتصال و تأیید Job در نسخه ۰.۶ فعال می‌شود.',
                ),
                icon: const Icon(Icons.print_outlined),
                label: const Text('بررسی اتصال و چاپ آزمایشی'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DataLine extends StatelessWidget {
  const _DataLine({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Text(value, style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    );
  }
}
