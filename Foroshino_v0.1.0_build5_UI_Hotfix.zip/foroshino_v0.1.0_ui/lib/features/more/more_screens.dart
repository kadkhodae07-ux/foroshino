import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/state.dart';
import '../../app/widgets.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  static const items = [
    _MoreItem('مشتریان', Icons.people_alt_outlined, '/customers'),
    _MoreItem('موجودی', Icons.warehouse_outlined, '/inventory'),
    _MoreItem('تأمین‌کنندگان', Icons.local_shipping_outlined, '/suppliers'),
    _MoreItem('هزینه‌ها', Icons.receipt_outlined, '/expenses'),
    _MoreItem('گزارش‌ها', Icons.insights_outlined, '/reports'),
    _MoreItem('کارمندان', Icons.badge_outlined, '/employees'),
    _MoreItem('پشتیبان‌گیری و همگام‌سازی', Icons.cloud_sync_outlined, '/backup-sync'),
    _MoreItem('تنظیمات فروشگاه', Icons.store_outlined, '/store-settings'),
    _MoreItem('تنظیمات برنامه', Icons.settings_outlined, '/settings'),
    _MoreItem('راهنما و پشتیبانی', Icons.support_agent_outlined, '/help'),
    _MoreItem('درباره فروشینو', Icons.info_outline_rounded, '/about'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('بیشتر')),
      body: PageFrame(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppCard(
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                    child: Icon(
                      Icons.storefront_rounded,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('فروشگاه شما', style: TextStyle(fontWeight: FontWeight.w800)),
                        SizedBox(height: 4),
                        Text('اطلاعات واقعی پس از ساخت فروشگاه نمایش داده می‌شود'),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => context.push('/store-settings'),
                    icon: const Icon(Icons.edit_outlined),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            ResponsiveGrid(
              minItemWidth: 250,
              childAspectRatio: 3.2,
              children: items
                  .map(
                    (item) => QuickActionTile(
                      icon: item.icon,
                      label: item.label,
                      onTap: () => context.push(item.route),
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class _MoreItem {
  const _MoreItem(this.label, this.icon, this.route);
  final String label;
  final IconData icon;
  final String route;
}

class CustomersScreen extends StatelessWidget {
  const CustomersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _CollectionPage(
      title: 'مشتریان',
      searchHint: 'جست‌وجوی نام یا شماره تماس',
      icon: Icons.people_alt_outlined,
      emptyTitle: 'هنوز مشتری‌ای اضافه نشده است',
      emptyMessage:
          'برای مشاهده سابقه خرید، بدهی و پرداخت‌ها، مشتری جدید اضافه کنید.',
      actionLabel: 'افزودن مشتری',
      onAction: () => context.push('/customers/new'),
      onPreview: () => context.push('/customers/profile'),
    );
  }
}

class CustomerFormScreen extends StatelessWidget {
  const CustomerFormScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _FormPage(
      title: 'مشتری جدید',
      sections: [
        _FormSectionData(
          title: 'اطلاعات پایه',
          fields: [
            _FieldData('نام و نام خانوادگی', Icons.person_outline_rounded),
            _FieldData('شماره موبایل', Icons.phone_android_rounded),
            _FieldData('ایمیل', Icons.alternate_email_rounded),
          ],
        ),
        _FormSectionData(
          title: 'اعتبار و یادداشت',
          fields: [
            _FieldData('سقف اعتبار', Icons.account_balance_wallet_outlined),
            _FieldData('تاریخ سررسید پیش‌فرض', Icons.event_outlined),
            _FieldData('یادداشت مشتری', Icons.notes_rounded, lines: 3),
          ],
        ),
        _FormSectionData(
          title: 'نشانی',
          fields: [
            _FieldData('عنوان نشانی', Icons.label_outline_rounded),
            _FieldData('نشانی کامل', Icons.location_on_outlined, lines: 3),
          ],
        ),
      ],
      submitLabel: 'ثبت مشتری',
      previewDescription:
          'در نسخه ۰.۱ اطلاعات مشتری ذخیره نمی‌شود و حساب بدهی ایجاد نخواهد شد.',
    );
  }
}

class CustomerProfileScreen extends StatelessWidget {
  const CustomerProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پروفایل مشتری')),
      body: PageFrame(
        maxWidth: 920,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            const AppCard(
              child: Column(
                children: [
                  CircleAvatar(radius: 34, child: Icon(Icons.person_outline_rounded, size: 32)),
                  SizedBox(height: 12),
                  Text('مشتری انتخاب نشده', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  SizedBox(height: 4),
                  Text('شماره تماس: —'),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const ResponsiveGrid(
              minItemWidth: 220,
              childAspectRatio: 2,
              children: [
                MetricCard(
                  icon: Icons.shopping_bag_outlined,
                  title: 'مجموع خرید',
                  value: '—',
                  caption: 'بدون خرید ثبت‌شده',
                ),
                MetricCard(
                  icon: Icons.account_balance_wallet_outlined,
                  title: 'بدهی جاری',
                  value: '—',
                  caption: 'بدون بدهی ثبت‌شده',
                ),
                MetricCard(
                  icon: Icons.payments_outlined,
                  title: 'آخرین پرداخت',
                  value: '—',
                  caption: 'بدون پرداخت ثبت‌شده',
                ),
              ],
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => context.push('/customers/payment'),
                icon: const Icon(Icons.payments_outlined),
                label: const Text('ثبت پرداخت مشتری'),
              ),
            ),
            const SizedBox(height: 18),
            const SectionHeader(title: 'تاریخچه خرید و پرداخت'),
            const SizedBox(height: 12),
            const EmptyState(
              icon: Icons.history_rounded,
              title: 'تاریخچه‌ای وجود ندارد',
              message: 'فروش‌ها، فاکتورها و پرداخت‌های واقعی مشتری اینجا نمایش داده می‌شوند.',
            ),
          ],
        ),
      ),
    );
  }
}

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('موجودی'),
        actions: [
          IconButton(
            onPressed: () => _showTransactionSheet(context),
            icon: const Icon(Icons.add_rounded),
            tooltip: 'عملیات موجودی',
          ),
        ],
      ),
      body: PageFrame(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ResponsiveGrid(
              minItemWidth: 220,
              childAspectRatio: 1.9,
              children: [
                MetricCard(
                  icon: Icons.inventory_2_outlined,
                  title: 'ارزش موجودی',
                  value: '—',
                  caption: 'پس از ثبت محصولات محاسبه می‌شود',
                ),
                MetricCard(
                  icon: Icons.warning_amber_rounded,
                  title: 'کم‌موجودی',
                  value: '—',
                  caption: 'حداقل موجودی تعریف نشده',
                ),
                MetricCard(
                  icon: Icons.event_busy_outlined,
                  title: 'نزدیک انقضا',
                  value: '—',
                  caption: 'بدون تاریخ انقضا ثبت‌شده',
                ),
              ],
            ),
            const SizedBox(height: 16),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('تراکنش‌ها')),
                  ButtonSegment(value: 1, label: Text('کم‌موجودی')),
                  ButtonSegment(value: 2, label: Text('انقضا')),
                  ButtonSegment(value: 3, label: Text('انبارگردانی')),
                ],
                selected: {tab},
                onSelectionChanged: (value) => setState(() => tab = value.first),
              ),
            ),
            const SizedBox(height: 14),
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            const EmptyState(
              icon: Icons.swap_vert_circle_outlined,
              title: 'تراکنش موجودی وجود ندارد',
              message:
                  'موجودی در نسخه عملکردی فقط از طریق تراکنش ورود، خروج، فروش، مرجوعی یا اصلاح تغییر می‌کند.',
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showTransactionSheet(BuildContext context) {
    const actions = [
      ('ورود موجودی', Icons.add_box_outlined),
      ('خروج موجودی', Icons.indeterminate_check_box_outlined),
      ('اصلاح موجودی', Icons.tune_rounded),
      ('کالای آسیب‌دیده', Icons.broken_image_outlined),
      ('مرجوعی مشتری', Icons.assignment_return_outlined),
      ('انبارگردانی', Icons.fact_check_outlined),
    ];
    return showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('عملیات موجودی', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              ...actions.map(
                (item) => ListTile(
                  leading: Icon(item.$2),
                  title: Text(item.$1),
                  trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                  onTap: () {
                    Navigator.of(context).pop();
                    context.push(
                      '/inventory/operation?type=${Uri.encodeComponent(item.$1)}',
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SuppliersScreen extends StatelessWidget {
  const SuppliersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _CollectionPage(
      title: 'تأمین‌کنندگان',
      searchHint: 'جست‌وجوی نام یا شماره تماس',
      icon: Icons.local_shipping_outlined,
      emptyTitle: 'تأمین‌کننده‌ای ثبت نشده است',
      emptyMessage:
          'برای مدیریت خرید، بدهی و سوابق قیمت خرید، تأمین‌کننده جدید اضافه کنید.',
      actionLabel: 'افزودن تأمین‌کننده',
      onAction: () => context.push('/suppliers/new'),
      onPreview: () => context.push('/suppliers/profile'),
    );
  }
}

class SupplierFormScreen extends StatelessWidget {
  const SupplierFormScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _FormPage(
      title: 'تأمین‌کننده جدید',
      sections: [
        _FormSectionData(
          title: 'مشخصات',
          fields: [
            _FieldData('نام تأمین‌کننده', Icons.business_outlined),
            _FieldData('نام شخص تماس', Icons.person_outline_rounded),
            _FieldData('شماره تماس', Icons.phone_outlined),
            _FieldData('ایمیل', Icons.alternate_email_rounded),
          ],
        ),
        _FormSectionData(
          title: 'اطلاعات تکمیلی',
          fields: [
            _FieldData('نشانی', Icons.location_on_outlined, lines: 3),
            _FieldData('یادداشت', Icons.notes_rounded, lines: 3),
          ],
        ),
      ],
      submitLabel: 'ثبت تأمین‌کننده',
      previewDescription:
          'در نسخه ۰.۱ اطلاعات تأمین‌کننده، خرید یا بدهی واقعی ذخیره نمی‌شود.',
    );
  }
}

class SupplierProfileScreen extends StatelessWidget {
  const SupplierProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پروفایل تأمین‌کننده')),
      body: PageFrame(
        maxWidth: 900,
        child: Column(
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            const ResponsiveGrid(
              minItemWidth: 220,
              childAspectRatio: 1.9,
              children: [
                MetricCard(
                  icon: Icons.shopping_cart_checkout_outlined,
                  title: 'مجموع خرید',
                  value: '—',
                  caption: 'بدون خرید ثبت‌شده',
                ),
                MetricCard(
                  icon: Icons.account_balance_wallet_outlined,
                  title: 'بدهی تأمین‌کننده',
                  value: '—',
                  caption: 'بدون بدهی ثبت‌شده',
                ),
                MetricCard(
                  icon: Icons.inventory_2_outlined,
                  title: 'محصولات مرتبط',
                  value: '—',
                  caption: 'بدون محصول مرتبط',
                ),
              ],
            ),
            const SizedBox(height: 14),
            LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 560;
                final purchase = FilledButton.icon(
                  onPressed: () => context.push('/purchases/new'),
                  icon: const Icon(Icons.shopping_cart_checkout_outlined),
                  label: const Text('ثبت فاکتور خرید'),
                );
                final returnButton = OutlinedButton.icon(
                  onPressed: () => context.push('/returns/new'),
                  icon: const Icon(Icons.assignment_return_outlined),
                  label: const Text('مرجوعی تأمین‌کننده'),
                );
                if (compact) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [purchase, const SizedBox(height: 10), returnButton],
                  );
                }
                return Row(
                  children: [
                    Expanded(child: purchase),
                    const SizedBox(width: 10),
                    Expanded(child: returnButton),
                  ],
                );
              },
            ),
            const SizedBox(height: 14),
            const EmptyState(
              icon: Icons.receipt_long_outlined,
              title: 'فاکتور خریدی وجود ندارد',
              message: 'فاکتورهای خرید و پرداخت‌های واقعی اینجا نمایش داده می‌شوند.',
            ),
          ],
        ),
      ),
    );
  }
}

class ExpensesScreen extends StatelessWidget {
  const ExpensesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _CollectionPage(
      title: 'هزینه‌ها',
      searchHint: 'جست‌وجوی عنوان یا دسته هزینه',
      icon: Icons.receipt_outlined,
      emptyTitle: 'هنوز هزینه‌ای ثبت نشده است',
      emptyMessage:
          'هزینه‌های اجاره، حقوق، ارسال، بسته‌بندی و سایر مخارج را ثبت کنید.',
      actionLabel: 'ثبت هزینه',
      onAction: () => context.push('/expenses/new'),
      onPreview: () => context.push('/expenses/details'),
    );
  }
}

class ExpenseFormScreen extends StatelessWidget {
  const ExpenseFormScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _FormPage(
      title: 'هزینه جدید',
      sections: [
        _FormSectionData(
          title: 'اطلاعات هزینه',
          fields: [
            _FieldData('عنوان هزینه', Icons.title_rounded),
            _FieldData('مبلغ', Icons.payments_outlined),
            _FieldData('دسته‌بندی', Icons.category_outlined),
            _FieldData('تاریخ', Icons.event_outlined),
            _FieldData('روش پرداخت', Icons.credit_card_outlined),
            _FieldData('تکرار هزینه', Icons.repeat_rounded),
          ],
        ),
        _FormSectionData(
          title: 'جزئیات',
          fields: [
            _FieldData('توضیحات', Icons.notes_rounded, lines: 3),
            _FieldData('تصویر رسید', Icons.add_a_photo_outlined),
          ],
        ),
      ],
      submitLabel: 'ثبت هزینه',
      previewDescription:
          'در نسخه ۰.۱ هزینه واقعی ثبت یا در گزارش سود محاسبه نمی‌شود.',
    );
  }
}

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  int range = 0;

  @override
  Widget build(BuildContext context) {
    final reports = [
      ('خلاصه فروش', Icons.bar_chart_rounded),
      ('سود تقریبی', Icons.trending_up_rounded),
      ('محصولات پرفروش', Icons.star_outline_rounded),
      ('محصولات کم‌فروش', Icons.trending_down_rounded),
      ('ارزش موجودی', Icons.inventory_2_outlined),
      ('روش‌های پرداخت', Icons.account_balance_wallet_outlined),
      ('بدهی مشتریان', Icons.people_alt_outlined),
      ('بدهی تأمین‌کنندگان', Icons.local_shipping_outlined),
      ('مرجوعی‌ها', Icons.assignment_return_outlined),
      ('عملکرد کارمندان', Icons.badge_outlined),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('گزارش‌ها'),
        actions: [
          IconButton(
            tooltip: 'خروجی گزارش',
            onPressed: () => showPreviewActionSheet(
              context,
              title: 'خروجی گزارش',
              description:
                  'خروجی PDF، CSV و Excel پس از فعال‌شدن داده‌های واقعی در نسخه ۰.۶ ساخته می‌شود.',
            ),
            icon: const Icon(Icons.ios_share_outlined),
          ),
        ],
      ),
      body: PageFrame(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('امروز')),
                  ButtonSegment(value: 1, label: Text('۷ روز')),
                  ButtonSegment(value: 2, label: Text('۳۰ روز')),
                  ButtonSegment(value: 3, label: Text('بازه دلخواه')),
                ],
                selected: {range},
                onSelectionChanged: (value) => setState(() => range = value.first),
              ),
            ),
            const SizedBox(height: 14),
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            const ResponsiveGrid(
              minItemWidth: 220,
              childAspectRatio: 1.8,
              children: [
                MetricCard(
                  icon: Icons.payments_outlined,
                  title: 'فروش خالص',
                  value: '—',
                  caption: 'داده‌ای برای این بازه وجود ندارد',
                ),
                MetricCard(
                  icon: Icons.trending_up_rounded,
                  title: 'سود تقریبی',
                  value: '—',
                  caption: 'پس از ثبت قیمت خرید و هزینه محاسبه می‌شود',
                ),
                MetricCard(
                  icon: Icons.receipt_long_outlined,
                  title: 'تعداد فاکتور',
                  value: '—',
                  caption: 'بدون فاکتور ثبت‌شده',
                ),
              ],
            ),
            const SizedBox(height: 18),
            const SectionHeader(title: 'گزارش‌های قابل بررسی'),
            const SizedBox(height: 12),
            ResponsiveGrid(
              minItemWidth: 250,
              childAspectRatio: 3.1,
              children: reports
                  .map(
                    (item) => QuickActionTile(
                      icon: item.$2,
                      label: item.$1,
                      onTap: () => _openReport(context, item.$1),
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openReport(BuildContext context, String title) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .72,
        minChildSize: .5,
        maxChildSize: .92,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 14),
            const EmptyState(
              icon: Icons.query_stats_rounded,
              title: 'داده‌ای برای تحلیل وجود ندارد',
              message:
                  'نمودارها فقط با تراکنش‌های واقعی ساخته می‌شوند و آمار تصادفی نمایش داده نمی‌شود.',
            ),
          ],
        ),
      ),
    );
  }
}

class EmployeesScreen extends StatelessWidget {
  const EmployeesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _CollectionPage(
      title: 'کارمندان',
      searchHint: 'جست‌وجوی نام یا نقش',
      icon: Icons.badge_outlined,
      emptyTitle: 'هنوز کارمندی دعوت نشده است',
      emptyMessage:
          'برای صندوق، موجودی یا سفارش‌ها دسترسی محدود و قابل کنترل تعریف کنید.',
      actionLabel: 'دعوت کارمند',
      onAction: () => context.push('/employees/new'),
      onPreview: () => context.push('/employees/profile'),
    );
  }
}

class EmployeeFormScreen extends StatefulWidget {
  const EmployeeFormScreen({super.key});

  @override
  State<EmployeeFormScreen> createState() => _EmployeeFormScreenState();
}

class _EmployeeFormScreenState extends State<EmployeeFormScreen> {
  final selected = <String>{'ایجاد فروش'};
  static const permissions = [
    'ایجاد فروش',
    'لغو فروش',
    'پردازش مرجوعی',
    'مشاهده قیمت خرید',
    'تغییر قیمت فروش',
    'مدیریت موجودی',
    'مشاهده مشتریان',
    'مشاهده بدهی‌ها',
    'مشاهده گزارش سود',
    'خروجی گزارش‌ها',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دعوت کارمند')),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          children: [
            const AppCard(
              child: Column(
                children: [
                  LabeledField(label: 'نام کارمند', icon: Icons.person_outline_rounded),
                  SizedBox(height: 14),
                  LabeledField(label: 'شماره موبایل یا ایمیل', icon: Icons.alternate_email_rounded),
                  SizedBox(height: 14),
                  LabeledField(label: 'نقش', hint: 'صندوق‌دار، مدیر موجودی، مدیر سفارش...', icon: Icons.badge_outlined),
                ],
              ),
            ),
            const SizedBox(height: 14),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader(
                    title: 'مجوزها',
                    subtitle: 'کنترل نهایی مجوزها در Backend انجام خواهد شد.',
                  ),
                  const SizedBox(height: 10),
                  ...permissions.map(
                    (permission) => CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      value: selected.contains(permission),
                      onChanged: (value) {
                        setState(() {
                          if (value ?? false) {
                            selected.add(permission);
                          } else {
                            selected.remove(permission);
                          }
                        });
                      },
                      title: Text(permission),
                      controlAffinity: ListTileControlAffinity.leading,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: 'ارسال دعوت',
                  description:
                      'دعوت واقعی کارمند، نقش و مجوزها در نسخه ۰.۶ فعال می‌شود.',
                ),
                child: const Text('ارسال دعوت'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class EmployeeProfileScreen extends StatelessWidget {
  const EmployeeProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('جزئیات کارمند')),
      body: const PageFrame(
        maxWidth: 860,
        child: Column(
          children: [
            PreviewBanner(),
            SizedBox(height: 14),
            EmptyState(
              icon: Icons.badge_outlined,
              title: 'کارمندی انتخاب نشده است',
              message:
                  'جزئیات نقش، دستگاه‌های متصل و تاریخچه فعالیت واقعی کارمند در این صفحه نمایش داده می‌شود.',
            ),
          ],
        ),
      ),
    );
  }
}

class BackupSyncScreen extends StatefulWidget {
  const BackupSyncScreen({super.key});

  @override
  State<BackupSyncScreen> createState() => _BackupSyncScreenState();
}

class _BackupSyncScreenState extends State<BackupSyncScreen> {
  bool autoBackup = true;
  bool wifiOnly = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پشتیبان‌گیری و همگام‌سازی')),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const PreviewBanner(),
            const SizedBox(height: 14),
            const ResponsiveGrid(
              minItemWidth: 220,
              childAspectRatio: 1.9,
              children: [
                MetricCard(
                  icon: Icons.cloud_done_outlined,
                  title: 'آخرین پشتیبان',
                  value: '—',
                  caption: 'هنوز پشتیبانی ساخته نشده',
                ),
                MetricCard(
                  icon: Icons.sync_outlined,
                  title: 'صف همگام‌سازی',
                  value: '—',
                  caption: 'عملیات محلی وجود ندارد',
                ),
                MetricCard(
                  icon: Icons.devices_outlined,
                  title: 'دستگاه‌های متصل',
                  value: '—',
                  caption: 'ثبت دستگاه در نسخه ۰.۲ فعال می‌شود',
                ),
              ],
            ),
            const SizedBox(height: 14),
            AppCard(
              child: Column(
                children: [
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: autoBackup,
                    onChanged: (value) => setState(() => autoBackup = value),
                    title: const Text('پشتیبان‌گیری خودکار'),
                    subtitle: const Text('پس از فعال‌شدن سرویس ابری رمزنگاری‌شده'),
                  ),
                  const Divider(),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: wifiOnly,
                    onChanged: (value) => setState(() => wifiOnly = value),
                    title: const Text('فقط با Wi-Fi'),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.backup_outlined),
                    title: const Text('ساخت پشتیبان دستی'),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => showPreviewActionSheet(
                      context,
                      title: 'پشتیبان دستی',
                      description:
                          'پشتیبان رمزنگاری‌شده و بازیابی امن در نسخه ۰.۵ فعال می‌شود.',
                    ),
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.restore_rounded),
                    title: const Text('بازیابی اطلاعات'),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => showPreviewActionSheet(
                      context,
                      title: 'بازیابی اطلاعات',
                      description:
                          'پیش‌نمایش و تأیید چندمرحله‌ای بازیابی در نسخه ۰.۵ فعال می‌شود.',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class StoreSettingsScreen extends StatelessWidget {
  const StoreSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const SettingsListScreen(
      title: 'تنظیمات فروشگاه',
      groups: [
        SettingsGroup(
          title: 'مشخصات فروشگاه',
          items: [
            SettingsItem('نام، لوگو و نشانی', Icons.storefront_outlined),
            SettingsItem('نوع کسب‌وکار', Icons.category_outlined),
            SettingsItem('شماره تماس', Icons.phone_outlined),
          ],
        ),
        SettingsGroup(
          title: 'فاکتور و مالی',
          items: [
            SettingsItem('قالب فاکتور', Icons.receipt_long_outlined, route: '/invoice-preview'),
            SettingsItem('مالیات', Icons.percent_rounded),
            SettingsItem('واحد پول', Icons.payments_outlined),
            SettingsItem('واحدهای محصول', Icons.straighten_rounded),
            SettingsItem('روش‌های پرداخت', Icons.credit_card_outlined),
          ],
        ),
      ],
    );
  }
}

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(themeModeProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات برنامه')),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          children: [
            AppCard(
              child: Column(
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.language_rounded),
                    title: const Text('زبان'),
                    subtitle: const Text('فارسی — راست‌به‌چپ'),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => showPreviewActionSheet(
                      context,
                      title: 'زبان برنامه',
                      description:
                          'تمام متن‌ها برای محلی‌سازی آماده شده‌اند. زبان انگلیسی در نسخه جداگانه قابل فعال‌سازی است.',
                    ),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.palette_outlined),
                    title: const Text('ظاهر'),
                    subtitle: Text(
                      mode == ThemeMode.dark
                          ? 'حالت تاریک'
                          : mode == ThemeMode.light
                              ? 'حالت روشن'
                              : 'هماهنگ با دستگاه',
                    ),
                    trailing: PopupMenuButton<ThemeMode>(
                      onSelected: ref.read(themeModeProvider.notifier).setMode,
                      itemBuilder: (context) => const [
                        PopupMenuItem(value: ThemeMode.system, child: Text('هماهنگ با دستگاه')),
                        PopupMenuItem(value: ThemeMode.light, child: Text('روشن')),
                        PopupMenuItem(value: ThemeMode.dark, child: Text('تاریک')),
                      ],
                    ),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.security_outlined),
                    title: const Text('امنیت'),
                    subtitle: const Text('قفل برنامه، نشست‌ها و دستگاه‌ها'),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => context.push('/device-security'),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.devices_outlined),
                    title: const Text('دستگاه‌های متصل'),
                    subtitle: const Text('نام دستگاه، آخرین فعالیت و خروج از راه دور'),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => context.push('/connected-devices'),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.notifications_outlined),
                    title: const Text('اعلان‌ها'),
                    subtitle: const Text('هشدار موجودی، بدهی، پشتیبان و نسخه جدید'),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => showPreviewActionSheet(
                      context,
                      title: 'تنظیمات اعلان',
                      description:
                          'زیرساخت اعلان در نسخه ۰.۷ فعال می‌شود و به ترجیحات کاربر احترام می‌گذارد.',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            AppCard(
              child: Column(
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.privacy_tip_outlined),
                    title: const Text('حریم خصوصی'),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => context.push('/terms'),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.delete_forever_outlined),
                    title: const Text('حذف حساب'),
                    textColor: Theme.of(context).colorScheme.error,
                    iconColor: Theme.of(context).colorScheme.error,
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => _confirmDelete(context),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.warning_amber_rounded),
        title: const Text('درخواست حذف حساب'),
        content: const Text(
          'در نسخه نهایی، حذف حساب دارای احراز هویت مجدد، مهلت بررسی و توضیح دقیق پیامدها خواهد بود. در نسخه ۰.۱ درخواستی ارسال نمی‌شود.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
        ],
      ),
    );
  }
}

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('راهنما و پشتیبانی')),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          children: [
            const TextField(
              decoration: InputDecoration(
                hintText: 'جست‌وجو در راهنما',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
            const SizedBox(height: 14),
            const AppCard(
              child: Column(
                children: [
                  _HelpTile('شروع کار با فروشینو', Icons.rocket_launch_outlined),
                  Divider(),
                  _HelpTile('محصول و بارکد', Icons.qr_code_2_rounded),
                  Divider(),
                  _HelpTile('فروش و فاکتور', Icons.point_of_sale_outlined),
                  Divider(),
                  _HelpTile('سفارش و ارسال', Icons.local_shipping_outlined),
                  Divider(),
                  _HelpTile('موجودی و انبارگردانی', Icons.warehouse_outlined),
                ],
              ),
            ),
            const SizedBox(height: 14),
            AppCard(
              child: ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const CircleAvatar(child: Icon(Icons.support_agent_outlined)),
                title: const Text('ارسال درخواست پشتیبانی'),
                subtitle: const Text('پیام، تصویر و اطلاعات فنی دستگاه'),
                trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                onTap: () => showPreviewActionSheet(
                  context,
                  title: 'تیکت پشتیبانی',
                  description:
                      'ثبت و پیگیری تیکت واقعی در نسخه ۰.۷ فعال می‌شود.',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HelpTile extends StatelessWidget {
  const _HelpTile(this.title, this.icon);
  final String title;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon),
      title: Text(title),
      trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
      onTap: () => showPreviewActionSheet(
        context,
        title: title,
        description:
            'محتوای راهنمای نهایی همزمان با فعال‌شدن هر قابلیت تکمیل خواهد شد.',
      ),
    );
  }
}

class AboutScreen extends StatefulWidget {
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> {
  int tapCount = 0;
  DateTime? lastTap;

  void _handleVersionTap() {
    final now = DateTime.now();
    if (lastTap == null || now.difference(lastTap!) > const Duration(seconds: 2)) {
      tapCount = 0;
    }
    lastTap = now;
    tapCount++;
    if (tapCount >= 7) {
      tapCount = 0;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('مسیر مدیریت امن فعال شد. احراز هویت مدیر لازم است.')),
      );
      context.push('/admin/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('درباره فروشینو')),
      body: PageFrame(
        maxWidth: 760,
        child: Column(
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary,
                borderRadius: BorderRadius.circular(28),
              ),
              child: const Icon(Icons.storefront_rounded, color: Colors.white, size: 50),
            ),
            const SizedBox(height: 16),
            Text('فروشینو', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 6),
            Text(
              'مدیریت ساده و حرفه‌ای فروشگاه‌های کوچک',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
            const SizedBox(height: 22),
            AppCard(
              child: Column(
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.new_releases_outlined),
                    title: const Text('نسخه برنامه'),
                    subtitle: const Text('۰.۱.۰ — بنیاد رابط کاربری'),
                    onTap: _handleVersionTap,
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.description_outlined),
                    title: const Text('شرایط استفاده'),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => context.push('/terms'),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.privacy_tip_outlined),
                    title: const Text('حریم خصوصی'),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                    onTap: () => context.push('/terms'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const PreviewBanner(compact: true),
          ],
        ),
      ),
    );
  }
}

class SettingsListScreen extends StatelessWidget {
  const SettingsListScreen({super.key, required this.title, required this.groups});

  final String title;
  final List<SettingsGroup> groups;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: groups
              .expand(
                (group) => [
                  SectionHeader(title: group.title),
                  const SizedBox(height: 10),
                  AppCard(
                    child: Column(
                      children: group.items.asMap().entries.map((entry) {
                        final item = entry.value;
                        return Column(
                          children: [
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: Icon(item.icon),
                              title: Text(item.title),
                              trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                              onTap: () {
                                if (item.route != null) {
                                  context.push(item.route!);
                                } else {
                                  showPreviewActionSheet(
                                    context,
                                    title: item.title,
                                    description:
                                        'ساختار این تنظیم آماده است و ذخیره‌سازی واقعی آن در نسخه مرتبط فعال می‌شود.',
                                  );
                                }
                              },
                            ),
                            if (entry.key < group.items.length - 1) const Divider(),
                          ],
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 18),
                ],
              )
              .toList(),
        ),
      ),
    );
  }
}

class SettingsGroup {
  const SettingsGroup({required this.title, required this.items});
  final String title;
  final List<SettingsItem> items;
}

class SettingsItem {
  const SettingsItem(this.title, this.icon, {this.route});
  final String title;
  final IconData icon;
  final String? route;
}

class _CollectionPage extends StatelessWidget {
  const _CollectionPage({
    required this.title,
    required this.searchHint,
    required this.icon,
    required this.emptyTitle,
    required this.emptyMessage,
    required this.actionLabel,
    required this.onAction,
    this.onPreview,
  });

  final String title;
  final String searchHint;
  final IconData icon;
  final String emptyTitle;
  final String emptyMessage;
  final String actionLabel;
  final VoidCallback onAction;
  final VoidCallback? onPreview;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'collection-$title-create-fab',
        onPressed: onAction,
        icon: const Icon(Icons.add_rounded),
        label: Text(actionLabel),
      ),
      body: PageFrame(
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: searchHint,
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: const Icon(Icons.filter_list_rounded),
              ),
            ),
            const SizedBox(height: 14),
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            EmptyState(
              icon: icon,
              title: emptyTitle,
              message: emptyMessage,
              primaryLabel: actionLabel,
              onPrimary: onAction,
              secondaryLabel: onPreview == null ? null : 'پیش‌نمایش جزئیات',
              onSecondary: onPreview,
            ),
          ],
        ),
      ),
    );
  }
}

class _FormPage extends StatelessWidget {
  const _FormPage({
    required this.title,
    required this.sections,
    required this.submitLabel,
    required this.previewDescription,
  });

  final String title;
  final List<_FormSectionData> sections;
  final String submitLabel;
  final String previewDescription;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: PageFrame(
        maxWidth: 820,
        child: Column(
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 14),
            ...sections.map(
              (section) => Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: AppCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SectionHeader(title: section.title),
                      const SizedBox(height: 14),
                      ...section.fields.asMap().entries.map(
                        (entry) => Padding(
                          padding: EdgeInsets.only(
                            bottom: entry.key == section.fields.length - 1 ? 0 : 14,
                          ),
                          child: LabeledField(
                            label: entry.value.label,
                            icon: entry.value.icon,
                            maxLines: entry.value.lines,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: submitLabel,
                  description: previewDescription,
                ),
                child: Text(submitLabel),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FormSectionData {
  const _FormSectionData({required this.title, required this.fields});
  final String title;
  final List<_FieldData> fields;
}

class _FieldData {
  const _FieldData(this.label, this.icon, {this.lines = 1});
  final String label;
  final IconData icon;
  final int lines;
}
