import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../app/widgets.dart';

class SalesScreen extends StatefulWidget {
  const SalesScreen({super.key});

  @override
  State<SalesScreen> createState() => _SalesScreenState();
}

class _SalesScreenState extends State<SalesScreen> {
  int payment = 0;
  bool showDetails = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('فروش جدید'),
        actions: [
          IconButton(
            tooltip: 'فروش‌های ذخیره‌شده',
            onPressed: () => showPreviewActionSheet(
              context,
              title: 'فروش‌های ذخیره‌شده',
              description:
                  'پیش‌نویس و تاریخچه فروش پس از فعال‌شدن پایگاه داده نمایش داده می‌شود.',
            ),
            icon: const Icon(Icons.history_rounded),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final wide = constraints.maxWidth >= 900;
          final catalog = _CatalogPanel(onScan: () => context.push('/barcode-tools?tab=scanner'));
          final cart = _CartPanel(
            payment: payment,
            showDetails: showDetails,
            onPaymentChanged: (value) => setState(() => payment = value),
            onShowDetailsChanged: (value) => setState(() => showDetails = value),
          );
          if (wide) {
            return SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 5,
                      child: SingleChildScrollView(child: catalog),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      flex: 4,
                      child: SingleChildScrollView(child: cart),
                    ),
                  ],
                ),
              ),
            );
          }
          return PageFrame(
            child: Column(
              children: [
                catalog,
                const SizedBox(height: 14),
                cart,
              ],
            ),
          );
        },
      ),
    );
  }
}

class _CatalogPanel extends StatelessWidget {
  const _CatalogPanel({required this.onScan});

  final VoidCallback onScan;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            decoration: InputDecoration(
              hintText: 'جست‌وجوی محصول یا بارکد',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: IconButton(
                onPressed: onScan,
                icon: const Icon(Icons.qr_code_scanner_rounded),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Wrap(
              spacing: 8,
              children: [
                FilterChip(label: Text('همه'), selected: true, onSelected: null),
                FilterChip(label: Text('پرفروش'), selected: false, onSelected: null),
                FilterChip(label: Text('اخیر'), selected: false, onSelected: null),
                FilterChip(label: Text('دسته‌بندی‌ها'), selected: false, onSelected: null),
              ],
            ),
          ),
          const SizedBox(height: 14),
          const PreviewBanner(compact: true),
          const SizedBox(height: 14),
          const EmptyState(
            icon: Icons.inventory_2_outlined,
            title: 'محصولی برای فروش وجود ندارد',
            message:
                'برای شروع فروش، ابتدا محصول واقعی اضافه کنید. این صفحه محصول آزمایشی ایجاد نمی‌کند.',
          ),
        ],
      ),
    );
  }
}

class _CartPanel extends StatelessWidget {
  const _CartPanel({
    required this.payment,
    required this.showDetails,
    required this.onPaymentChanged,
    required this.onShowDetailsChanged,
  });

  final int payment;
  final bool showDetails;
  final ValueChanged<int> onPaymentChanged;
  final ValueChanged<bool> onShowDetailsChanged;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: 'سبد فروش',
            subtitle: '۰ قلم کالا',
          ),
          const SizedBox(height: 12),
          ConstrainedBox(
            constraints: const BoxConstraints(minHeight: 180),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerLow,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.shopping_cart_outlined, size: 52),
                      SizedBox(height: 12),
                      Text('سبد فروش خالی است'),
                      SizedBox(height: 4),
                      Text(
                        'محصول را جست‌وجو یا بارکد آن را اسکن کنید.',
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const CircleAvatar(child: Icon(Icons.person_add_alt_1_outlined)),
            title: const Text('انتخاب مشتری'),
            subtitle: const Text('فروش نقدی بدون مشتری نیز امکان‌پذیر است'),
            trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
            onTap: () => context.push('/customers'),
          ),
          const Divider(),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('جزئیات قیمت و تخفیف'),
            trailing: Switch(value: showDetails, onChanged: onShowDetailsChanged),
          ),
          if (showDetails) ...[
            const _SummaryRow(label: 'جمع کالاها', value: '۰ تومان'),
            const _SummaryRow(label: 'تخفیف', value: '۰ تومان'),
            const _SummaryRow(label: 'مالیات', value: '۰ تومان'),
            const _SummaryRow(label: 'هزینه ارسال', value: '۰ تومان'),
            const Divider(),
            const _SummaryRow(label: 'مبلغ نهایی', value: '۰ تومان', emphasized: true),
          ],
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, icon: Icon(Icons.payments_outlined), label: Text('نقدی')),
                ButtonSegment(value: 1, icon: Icon(Icons.credit_card_rounded), label: Text('کارت')),
                ButtonSegment(value: 2, icon: Icon(Icons.call_split_rounded), label: Text('ترکیبی')),
              ],
              selected: {payment},
              onSelectionChanged: (value) => onPaymentChanged(value.first),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => context.push('/sale-confirmation'),
              icon: const Icon(Icons.receipt_long_outlined),
              label: const Text('ادامه و بررسی فروش'),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({required this.label, required this.value, this.emphasized = false});

  final String label;
  final String value;
  final bool emphasized;

  @override
  Widget build(BuildContext context) {
    final style = emphasized
        ? Theme.of(context).textTheme.titleMedium
        : Theme.of(context).textTheme.bodyMedium;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label, style: style)),
          Text(value, style: style),
        ],
      ),
    );
  }
}

class SaleConfirmationScreen extends StatefulWidget {
  const SaleConfirmationScreen({super.key});

  @override
  State<SaleConfirmationScreen> createState() => _SaleConfirmationScreenState();
}

class _SaleConfirmationScreenState extends State<SaleConfirmationScreen> {
  bool invoice = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('بررسی و تأیید فروش')),
      body: PageFrame(
        maxWidth: 760,
        child: Column(
          children: [
            const PreviewBanner(),
            const SizedBox(height: 14),
            const AppCard(
              child: Column(
                children: [
                  _ReviewRow(label: 'تعداد اقلام', value: '۰'),
                  Divider(),
                  _ReviewRow(label: 'جمع فروش', value: '۰ تومان'),
                  _ReviewRow(label: 'پرداخت‌شده', value: '۰ تومان'),
                  _ReviewRow(label: 'مانده', value: '۰ تومان'),
                ],
              ),
            ),
            const SizedBox(height: 14),
            AppCard(
              child: Column(
                children: [
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: invoice,
                    onChanged: (value) => setState(() => invoice = value),
                    title: const Text('پس از فروش فاکتور ساخته شود'),
                    subtitle: const Text('در نسخه عملکردی، خروجی واقعی ایجاد می‌شود'),
                  ),
                  if (invoice) ...[
                    const Divider(),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.receipt_long_outlined),
                      title: const Text('قالب فاکتور'),
                      subtitle: const Text('A4 استاندارد'),
                      trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
                      onTap: () => context.push('/invoice-preview'),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: 'ثبت نهایی فروش',
                  description:
                      'در نسخه ۰.۱ هیچ فروش، پرداخت، بدهی یا تراکنش موجودی ایجاد نمی‌شود. این دکمه فقط رفتار ایمن نسخه رابط را نمایش می‌دهد.',
                ),
                icon: const Icon(Icons.check_circle_outline_rounded),
                label: const Text('ثبت نهایی فروش'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReviewRow extends StatelessWidget {
  const _ReviewRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Text(value, style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    );
  }
}

class InvoicePreviewScreen extends StatefulWidget {
  const InvoicePreviewScreen({super.key});

  @override
  State<InvoicePreviewScreen> createState() => _InvoicePreviewScreenState();
}

class _InvoicePreviewScreenState extends State<InvoicePreviewScreen> {
  int format = 0;
  bool logo = true;
  bool qr = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('پیش‌نمایش فاکتور'),
        actions: [
          IconButton(
            tooltip: 'تنظیم قالب',
            onPressed: () => _showSettings(context),
            icon: const Icon(Icons.tune_rounded),
          ),
        ],
      ),
      body: PageFrame(
        maxWidth: 960,
        child: Column(
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('A4')),
                  ButtonSegment(value: 1, label: Text('حرارتی')),
                  ButtonSegment(value: 2, label: Text('تصویر')),
                ],
                selected: {format},
                onSelectionChanged: (value) => setState(() => format = value.first),
              ),
            ),
            const SizedBox(height: 14),
            AppCard(
              padding: EdgeInsets.zero,
              child: Container(
                width: double.infinity,
                constraints: BoxConstraints(
                  minHeight: format == 1 ? 620 : 760,
                  maxWidth: format == 1 ? 380 : 760,
                ),
                color: Colors.white,
                padding: EdgeInsets.all(format == 1 ? 18 : 30),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (logo)
                        const Align(
                          child: CircleAvatar(
                            radius: 28,
                            backgroundColor: Color(0xFFE5E7EB),
                            child: Icon(Icons.storefront_rounded, color: Colors.black54),
                          ),
                        ),
                      const SizedBox(height: 12),
                      const Text(
                        'فروشینو',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.black87,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'پیش‌نمایش قالب فاکتور — بدون داده تجاری',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black54),
                      ),
                      const SizedBox(height: 20),
                      const Divider(color: Colors.black26),
                      const _InvoiceLine(label: 'شماره فاکتور', value: '—'),
                      const _InvoiceLine(label: 'تاریخ', value: '—'),
                      const _InvoiceLine(label: 'مشتری', value: '—'),
                      const Divider(color: Colors.black26),
                      const SizedBox(
                        height: 360,
                        child: Center(
                          child: Text(
                            'هیچ قلم کالایی ثبت نشده است',
                            style: TextStyle(color: Colors.black54),
                          ),
                        ),
                      ),
                      const Divider(color: Colors.black26),
                      const _InvoiceLine(label: 'جمع کل', value: '۰ تومان', bold: true),
                      const _InvoiceLine(label: 'پرداخت‌شده', value: '۰ تومان'),
                      const _InvoiceLine(label: 'مانده', value: '۰ تومان'),
                      if (qr) ...[
                        const SizedBox(height: 18),
                        const Align(
                          child: Icon(Icons.qr_code_2_rounded, size: 72, color: Colors.black87),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: [
                FilledButton.icon(
                  onPressed: () => _notAvailable(context, 'PDF'),
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                  label: const Text('خروجی PDF'),
                ),
                OutlinedButton.icon(
                  onPressed: () => _notAvailable(context, 'تصویر'),
                  icon: const Icon(Icons.image_outlined),
                  label: const Text('خروجی تصویر'),
                ),
                OutlinedButton.icon(
                  onPressed: () => context.push('/printer-setup'),
                  icon: const Icon(Icons.print_outlined),
                  label: const Text('چاپ'),
                ),
                OutlinedButton.icon(
                  onPressed: () => _notAvailable(context, 'اشتراک‌گذاری'),
                  icon: const Icon(Icons.share_outlined),
                  label: const Text('اشتراک‌گذاری'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showSettings(BuildContext context) {
    return showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: StatefulBuilder(
          builder: (context, setLocalState) => Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('تنظیمات قالب', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 10),
                SwitchListTile(
                  value: logo,
                  onChanged: (value) {
                    setState(() => logo = value);
                    setLocalState(() {});
                  },
                  title: const Text('نمایش لوگو'),
                ),
                SwitchListTile(
                  value: qr,
                  onChanged: (value) {
                    setState(() => qr = value);
                    setLocalState(() {});
                  },
                  title: const Text('نمایش QR Code'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _notAvailable(BuildContext context, String output) {
    return showPreviewActionSheet(
      context,
      title: 'خروجی $output',
      description:
          'تولید و ذخیره فایل واقعی در نسخه ۰.۳ فعال می‌شود و موفقیت ساخت یا چاپ در نسخه ۰.۱ شبیه‌سازی نمی‌شود.',
    );
  }
}

class _InvoiceLine extends StatelessWidget {
  const _InvoiceLine({required this.label, required this.value, this.bold = false});

  final String label;
  final String value;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    final style = TextStyle(
      color: Colors.black87,
      fontWeight: bold ? FontWeight.bold : FontWeight.normal,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(child: Text(label, style: style)),
          Text(value, style: style),
        ],
      ),
    );
  }
}
