import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../app/widgets.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  bool grid = false;
  int filter = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('محصولات'),
        actions: [
          IconButton(
            tooltip: grid ? 'نمایش فهرستی' : 'نمایش شبکه‌ای',
            onPressed: () => setState(() => grid = !grid),
            icon: Icon(grid ? Icons.view_list_rounded : Icons.grid_view_rounded),
          ),
          IconButton(
            tooltip: 'ابزار بارکد',
            onPressed: () => context.push('/barcode-tools'),
            icon: const Icon(Icons.qr_code_2_rounded),
          ),
          const SizedBox(width: 6),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'products-create-fab',
        onPressed: () => context.push('/products/new'),
        icon: const Icon(Icons.add_rounded),
        label: const Text('محصول جدید'),
      ),
      body: PageFrame(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'جست‌وجوی نام، کد داخلی یا بارکد',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: IconButton(
                  onPressed: () => context.push('/barcode-tools?tab=scanner'),
                  icon: const Icon(Icons.qr_code_scanner_rounded),
                ),
              ),
            ),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('همه')),
                  ButtonSegment(value: 1, label: Text('فعال')),
                  ButtonSegment(value: 2, label: Text('کم‌موجودی')),
                  ButtonSegment(value: 3, label: Text('بایگانی')),
                ],
                selected: {filter},
                onSelectionChanged: (value) => setState(() => filter = value.first),
              ),
            ),
            const SizedBox(height: 18),
            const PreviewBanner(compact: true),
            const SizedBox(height: 18),
            EmptyState(
              icon: Icons.inventory_2_outlined,
              title: 'هنوز محصولی اضافه نشده است',
              message:
                  'محصول اول را به‌صورت دستی اضافه کنید یا برای ورود سریع، بارکد آن را اسکن کنید.',
              primaryLabel: 'افزودن اولین محصول',
              onPrimary: () => context.push('/products/new'),
              secondaryLabel: 'اسکن بارکد',
              onSecondary: () => context.push('/barcode-tools?tab=scanner'),
            ),
            const SizedBox(height: 20),
            const SectionHeader(
              title: 'حالت بارگذاری محصولات',
              subtitle: 'اسکلت بارگذاری تا زمان دریافت داده واقعی نمایش داده می‌شود.',
            ),
            const SizedBox(height: 12),
            _ProductSkeleton(grid: grid),
          ],
        ),
      ),
    );
  }
}

class _ProductSkeleton extends StatelessWidget {
  const _ProductSkeleton({required this.grid});

  final bool grid;

  @override
  Widget build(BuildContext context) {
    final card = AppCard(
      child: Row(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              Icons.image_outlined,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 130,
                  height: 12,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  width: 88,
                  height: 10,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.more_vert_rounded),
        ],
      ),
    );
    return grid
        ? ResponsiveGrid(
            minItemWidth: 280,
            childAspectRatio: 3.4,
            children: [card, card],
          )
        : Column(children: [card, const SizedBox(height: 10), card]);
  }
}

class ProductFormScreen extends StatefulWidget {
  const ProductFormScreen({super.key, this.editing = false});

  final bool editing;

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen>
    with SingleTickerProviderStateMixin {
  late final TabController tabController;
  bool active = true;
  bool hasVariants = false;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.editing ? 'ویرایش محصول' : 'محصول جدید'),
        bottom: TabBar(
          controller: tabController,
          isScrollable: true,
          tabs: const [
            Tab(text: 'اطلاعات پایه'),
            Tab(text: 'گزینه‌های بیشتر'),
            Tab(text: 'تنوع‌ها'),
          ],
        ),
      ),
      body: TabBarView(
        controller: tabController,
        children: [
          PageFrame(maxWidth: 820, child: _basicTab(context)),
          const PageFrame(maxWidth: 820, child: _MoreOptionsTab()),
          PageFrame(maxWidth: 820, child: _variantsTab(context)),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final saveButton = FilledButton.icon(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: widget.editing ? 'ذخیره ویرایش محصول' : 'ثبت محصول جدید',
                  description:
                      'در نسخه ۰.۱ فرم و اعتبارسنجی ظاهری آماده است، اما اطلاعات در پایگاه داده ثبت نمی‌شود.',
                ),
                icon: const Icon(Icons.save_outlined),
                label: Text(widget.editing ? 'ذخیره تغییرات' : 'ثبت محصول'),
              );
              final cancelButton = OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('انصراف'),
              );

              if (constraints.maxWidth < 330) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(width: double.infinity, child: saveButton),
                    const SizedBox(height: 8),
                    SizedBox(width: double.infinity, child: cancelButton),
                  ],
                );
              }

              return Row(
                children: [
                  Expanded(child: cancelButton),
                  const SizedBox(width: 10),
                  Expanded(flex: 2, child: saveButton),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _basicTab(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const PreviewBanner(compact: true),
        const SizedBox(height: 16),
        AppCard(
          child: Column(
            children: [
              InkWell(
                onTap: () => showPreviewActionSheet(
                  context,
                  title: 'افزودن تصویر محصول',
                  description:
                      'انتخاب، برش و فشرده‌سازی امن تصویر در نسخه ۰.۲ فعال می‌شود.',
                ),
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  width: 112,
                  height: 112,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Icon(
                    Icons.add_photo_alternate_outlined,
                    size: 40,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const LabeledField(
                label: 'نام محصول',
                hint: 'نام واضح و قابل جست‌وجو',
                icon: Icons.inventory_2_outlined,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'دسته‌بندی',
                  prefixIcon: Icon(Icons.category_outlined),
                ),
                items: const [],
                onChanged: null,
                hint: const Text(
                  'دسته‌بندی تعریف نشده',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(height: 16),
              LayoutBuilder(
                builder: (context, constraints) {
                  final scannerButton = IconButton.filledTonal(
                    tooltip: 'اسکن بارکد',
                    onPressed: () => context.push('/barcode-tools?tab=scanner'),
                    icon: const Icon(Icons.qr_code_scanner_rounded),
                  );

                  if (constraints.maxWidth < 300) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const LabeledField(
                          label: 'بارکد',
                          hint: 'ورود دستی یا اسکن',
                          icon: Icons.qr_code_rounded,
                          keyboardType: TextInputType.number,
                        ),
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: scannerButton,
                        ),
                      ],
                    );
                  }

                  return Row(
                    children: [
                      const Expanded(
                        child: LabeledField(
                          label: 'بارکد',
                          hint: 'ورود دستی یا اسکن',
                          icon: Icons.qr_code_rounded,
                          keyboardType: TextInputType.number,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Padding(
                        padding: const EdgeInsets.only(top: 28),
                        child: scannerButton,
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 16),
              const ResponsiveGrid(
                minItemWidth: 220,
                children: [
                  LabeledField(
                    label: 'قیمت فروش',
                    hint: '۰',
                    icon: Icons.sell_outlined,
                    keyboardType: TextInputType.number,
                  ),
                  LabeledField(
                    label: 'موجودی فعلی',
                    hint: '۰',
                    icon: Icons.layers_outlined,
                    keyboardType: TextInputType.number,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: active,
                onChanged: (value) => setState(() => active = value),
                title: const Text('محصول فعال باشد'),
                subtitle: const Text('محصول غیرفعال در فروش جدید نمایش داده نمی‌شود'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _variantsTab(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppCard(
          child: SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: hasVariants,
            onChanged: (value) => setState(() => hasVariants = value),
            title: const Text('این محصول تنوع دارد'),
            subtitle: const Text('مانند رنگ، سایز، وزن یا حجم'),
          ),
        ),
        const SizedBox(height: 14),
        if (!hasVariants)
          const EmptyState(
            icon: Icons.tune_rounded,
            title: 'تنوع محصول غیرفعال است',
            message:
                'برای تعریف بارکد، قیمت و موجودی جداگانه برای هر گزینه، تنوع محصول را فعال کنید.',
          )
        else ...[
          const SectionHeader(
            title: 'گزینه‌های تنوع',
            subtitle: 'در نسخه عملکردی، ترکیب گزینه‌ها به‌صورت کنترل‌شده ساخته می‌شود.',
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(
              children: [
                const LabeledField(
                  label: 'نام گزینه',
                  hint: 'مثلاً رنگ یا سایز',
                  icon: Icons.tune_rounded,
                ),
                const SizedBox(height: 14),
                const LabeledField(
                  label: 'مقادیر گزینه',
                  hint: 'مثلاً مشکی، سفید، آبی',
                  icon: Icons.list_alt_rounded,
                ),
                const SizedBox(height: 14),
                Align(
                  alignment: Alignment.centerLeft,
                  child: OutlinedButton.icon(
                    onPressed: () => showPreviewActionSheet(
                      context,
                      title: 'افزودن گزینه تنوع',
                      description:
                          'ساخت و ترکیب گزینه‌های واقعی محصول در نسخه ۰.۲ فعال می‌شود.',
                    ),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('افزودن گزینه دیگر'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

class _MoreOptionsTab extends StatelessWidget {
  const _MoreOptionsTab();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        AppCard(
          child: Column(
            children: [
              ResponsiveGrid(
                minItemWidth: 220,
                children: [
                  LabeledField(
                    label: 'قیمت خرید',
                    hint: '۰',
                    icon: Icons.shopping_cart_checkout_rounded,
                    keyboardType: TextInputType.number,
                  ),
                  LabeledField(
                    label: 'قیمت عمده',
                    hint: '۰',
                    icon: Icons.inventory_rounded,
                    keyboardType: TextInputType.number,
                  ),
                ],
              ),
              SizedBox(height: 16),
              ResponsiveGrid(
                minItemWidth: 220,
                children: [
                  LabeledField(
                    label: 'حداقل موجودی',
                    hint: '۰',
                    icon: Icons.warning_amber_rounded,
                    keyboardType: TextInputType.number,
                  ),
                  LabeledField(
                    label: 'کد داخلی',
                    hint: 'اختیاری',
                    icon: Icons.tag_rounded,
                  ),
                ],
              ),
              SizedBox(height: 16),
              LabeledField(
                label: 'تأمین‌کننده',
                hint: 'انتخاب تأمین‌کننده',
                icon: Icons.local_shipping_outlined,
              ),
              SizedBox(height: 16),
              ResponsiveGrid(
                minItemWidth: 220,
                children: [
                  LabeledField(
                    label: 'واحد',
                    hint: 'عدد، بسته، کیلوگرم...',
                    icon: Icons.straighten_rounded,
                  ),
                  LabeledField(
                    label: 'تاریخ انقضا',
                    hint: 'اختیاری',
                    icon: Icons.event_outlined,
                  ),
                ],
              ),
              SizedBox(height: 16),
              LabeledField(
                label: 'توضیحات',
                hint: 'یادداشت داخلی درباره محصول',
                icon: Icons.notes_rounded,
                maxLines: 4,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class ProductDetailsScreen extends StatelessWidget {
  const ProductDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('جزئیات محصول'),
        actions: [
          IconButton(
            tooltip: 'ویرایش',
            onPressed: () => context.push('/products/edit'),
            icon: const Icon(Icons.edit_outlined),
          ),
          PopupMenuButton<String>(
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'archive', child: Text('بایگانی محصول')),
              PopupMenuItem(value: 'delete', child: Text('حذف محصول')),
            ],
          ),
        ],
      ),
      body: PageFrame(
        maxWidth: 900,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 16),
            AppCard(
              child: Column(
                children: [
                  Container(
                    width: 104,
                    height: 104,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: const Icon(Icons.image_outlined, size: 38),
                  ),
                  const SizedBox(height: 16),
                  Text('نام محصول ثبت نشده', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 6),
                  Text(
                    'اطلاعات واقعی پس از فعال‌شدن پایگاه داده نمایش داده می‌شود.',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                  const SizedBox(height: 18),
                  const ResponsiveGrid(
                    minItemWidth: 210,
                    childAspectRatio: 2.3,
                    children: [
                      _InfoTile(icon: Icons.sell_outlined, label: 'قیمت فروش', value: '—'),
                      _InfoTile(icon: Icons.layers_outlined, label: 'موجودی', value: '—'),
                      _InfoTile(icon: Icons.qr_code_rounded, label: 'بارکد', value: '—'),
                      _InfoTile(icon: Icons.category_outlined, label: 'دسته‌بندی', value: '—'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const SectionHeader(title: 'تاریخچه موجودی'),
            const SizedBox(height: 12),
            const EmptyState(
              icon: Icons.history_rounded,
              title: 'تراکنش موجودی وجود ندارد',
              message:
                  'هر تغییر موجودی در نسخه ۰.۳ به‌صورت تراکنش مستقل و قابل پیگیری ثبت خواهد شد.',
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: Theme.of(context).textTheme.bodySmall),
                Text(value, style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class BarcodeToolsScreen extends StatefulWidget {
  const BarcodeToolsScreen({super.key, this.initialTab = 0});

  final int initialTab;

  @override
  State<BarcodeToolsScreen> createState() => _BarcodeToolsScreenState();
}

class _BarcodeToolsScreenState extends State<BarcodeToolsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController controller;

  @override
  void initState() {
    super.initState();
    controller = TabController(length: 3, vsync: this, initialIndex: widget.initialTab);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ابزار بارکد'),
        bottom: TabBar(
          controller: controller,
          tabs: const [
            Tab(text: 'اسکن'),
            Tab(text: 'ساخت'),
            Tab(text: 'برچسب و چاپ'),
          ],
        ),
      ),
      body: TabBarView(
        controller: controller,
        children: const [
          _ScannerTab(),
          _GeneratorTab(),
          _LabelTab(),
        ],
      ),
    );
  }
}

class _ScannerTab extends StatelessWidget {
  const _ScannerTab();

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      maxWidth: 760,
      child: Column(
        children: [
          AspectRatio(
            aspectRatio: 1,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Container(
                      width: 220,
                      height: 150,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.white, width: 2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                  const Positioned(
                    left: 16,
                    right: 16,
                    bottom: 18,
                    child: Text(
                      'بارکد را داخل کادر قرار دهید',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                    ),
                  ),
                  const Positioned(
                    top: 14,
                    left: 14,
                    child: IconButton.filledTonal(
                      onPressed: null,
                      icon: Icon(Icons.flash_off_rounded),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          const PreviewBanner(compact: true),
          const SizedBox(height: 14),
          const LabeledField(
            label: 'ورود دستی بارکد',
            hint: 'شماره بارکد را وارد کنید',
            icon: Icons.keyboard_rounded,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 12),
          const SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: null,
              child: Text('بررسی بارکد'),
            ),
          ),
        ],
      ),
    );
  }
}

class _GeneratorTab extends StatefulWidget {
  const _GeneratorTab();

  @override
  State<_GeneratorTab> createState() => _GeneratorTabState();
}

class _GeneratorTabState extends State<_GeneratorTab> {
  int type = 0;

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      maxWidth: 760,
      child: Column(
        children: [
          AppCard(
            child: Column(
              children: [
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 0, label: Text('Code 128')),
                    ButtonSegment(value: 1, label: Text('QR Code')),
                  ],
                  selected: {type},
                  onSelectionChanged: (value) => setState(() => type = value.first),
                ),
                const SizedBox(height: 18),
                const LabeledField(
                  label: 'مقدار کد',
                  hint: 'کد داخلی یا شناسه محصول',
                  icon: Icons.numbers_rounded,
                ),
                const SizedBox(height: 18),
                Container(
                  height: 180,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                  ),
                  child: Center(
                    child: Icon(
                      type == 0 ? Icons.view_week_outlined : Icons.qr_code_2_rounded,
                      size: 96,
                      color: Colors.black87,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () => showPreviewActionSheet(
                      context,
                      title: 'ساخت بارکد',
                      description:
                          'تولید فایل واقعی Code 128 و QR در نسخه ۰.۲ فعال خواهد شد.',
                    ),
                    icon: const Icon(Icons.auto_awesome_outlined),
                    label: const Text('ساخت پیش‌نمایش'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LabelTab extends StatelessWidget {
  const _LabelTab();

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      maxWidth: 900,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: 'تنظیم برچسب',
            subtitle: 'ابعاد، فاصله و نوع کاغذ پیش از ساخت فایل انتخاب می‌شود.',
          ),
          const SizedBox(height: 14),
          const AppCard(
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: LabeledField(
                        label: 'عرض برچسب',
                        hint: 'میلی‌متر',
                        icon: Icons.width_normal_rounded,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: LabeledField(
                        label: 'ارتفاع برچسب',
                        hint: 'میلی‌متر',
                        icon: Icons.height_rounded,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                LabeledField(
                  label: 'نوع خروجی',
                  hint: 'A4 یا لیبل حرارتی',
                  icon: Icons.print_outlined,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const SectionHeader(title: 'پیش‌نمایش برگه A4'),
          const SizedBox(height: 12),
          AppCard(
            child: AspectRatio(
              aspectRatio: 1 / 1.414,
              child: Container(
                padding: const EdgeInsets.all(18),
                color: Colors.white,
                child: GridView.count(
                  crossAxisCount: 3,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  physics: const NeverScrollableScrollPhysics(),
                  children: List.generate(
                    12,
                    (index) => Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black12),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Icon(Icons.view_week_outlined, color: Colors.black54),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => showPreviewActionSheet(
                context,
                title: 'ساخت فایل برچسب',
                description:
                    'خروجی PDF و تصویر واقعی در نسخه ۰.۲ ایجاد می‌شود. در این نسخه موفقیت چاپ شبیه‌سازی نمی‌شود.',
              ),
              icon: const Icon(Icons.picture_as_pdf_outlined),
              label: const Text('ساخت فایل PDF'),
            ),
          ),
        ],
      ),
    );
  }
}
