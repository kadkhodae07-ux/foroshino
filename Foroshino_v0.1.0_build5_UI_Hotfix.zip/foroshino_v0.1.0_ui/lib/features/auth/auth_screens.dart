import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../app/widgets.dart';

class AuthLayout extends StatelessWidget {
  const AuthLayout({
    super.key,
    required this.title,
    required this.subtitle,
    required this.child,
    this.footer,
  });

  final String title;
  final String subtitle;
  final Widget child;
  final Widget? footer;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        top: false,
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: const Icon(Icons.storefront_rounded, color: Colors.white, size: 30),
                  ),
                  const SizedBox(height: 24),
                  Text(title, style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 8),
                  Text(
                    subtitle,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                  const SizedBox(height: 28),
                  AppCard(child: child),
                  const SizedBox(height: 14),
                  const PreviewBanner(compact: true),
                  if (footer != null) ...[const SizedBox(height: 16), footer!],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      title: 'ورود به فروشینو',
      subtitle: 'برای ادامه، اطلاعات حساب فروشگاه را وارد کنید.',
      child: Column(
        children: [
          const LabeledField(
            label: 'ایمیل یا شماره موبایل',
            hint: 'ایمیل کاری یا شخصی',
            icon: Icons.person_outline_rounded,
            keyboardType: TextInputType.emailAddress,
          ),
          const SizedBox(height: 16),
          const LabeledField(
            label: 'رمز عبور',
            hint: 'رمز عبور',
            icon: Icons.lock_outline_rounded,
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton(
              onPressed: () => context.push('/forgot-password'),
              child: const Text('رمز عبور را فراموش کرده‌ام'),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => context.go('/home'),
              child: const Text('مشاهده محیط فروشینو'),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => context.go('/register'),
              child: const Text('ساخت حساب جدید'),
            ),
          ),
        ],
      ),
    );
  }
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  bool accepted = false;

  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      title: 'ساخت حساب فروشگاه',
      subtitle: 'اطلاعات پایه را وارد کنید؛ جزئیات فروشگاه در مرحله بعد تکمیل می‌شود.',
      footer: TextButton(
        onPressed: () => context.go('/login'),
        child: const Text('حساب دارید؟ وارد شوید'),
      ),
      child: Column(
        children: [
          const LabeledField(
            label: 'نام و نام خانوادگی',
            hint: 'نام صاحب فروشگاه',
            icon: Icons.badge_outlined,
          ),
          const SizedBox(height: 16),
          const LabeledField(
            label: 'شماره موبایل',
            hint: '09xxxxxxxxx',
            icon: Icons.phone_android_rounded,
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 16),
          const LabeledField(
            label: 'ایمیل',
            hint: 'اختیاری در رابط نسخه ۰.۱',
            icon: Icons.alternate_email_rounded,
            keyboardType: TextInputType.emailAddress,
          ),
          const SizedBox(height: 16),
          const LabeledField(
            label: 'رمز عبور',
            hint: 'حداقل ۸ نویسه',
            icon: Icons.lock_outline_rounded,
          ),
          const SizedBox(height: 10),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            value: accepted,
            onChanged: (value) => setState(() => accepted = value ?? false),
            title: const Text('شرایط استفاده و حریم خصوصی را می‌پذیرم.'),
            controlAffinity: ListTileControlAffinity.leading,
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: accepted ? () => context.push('/verify') : null,
              child: const Text('ادامه و دریافت کد تأیید'),
            ),
          ),
        ],
      ),
    );
  }
}

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      title: 'بازیابی رمز عبور',
      subtitle: 'شماره موبایل یا ایمیل ثبت‌شده را وارد کنید.',
      child: Column(
        children: [
          const LabeledField(
            label: 'ایمیل یا شماره موبایل',
            hint: 'اطلاعات حساب',
            icon: Icons.key_rounded,
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => context.push('/verify?flow=reset'),
              child: const Text('ارسال کد بازیابی'),
            ),
          ),
        ],
      ),
    );
  }
}

class VerificationScreen extends StatelessWidget {
  const VerificationScreen({super.key, required this.resetFlow});

  final bool resetFlow;

  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      title: 'تأیید کد امنیتی',
      subtitle: 'کد شش‌رقمی ارسال‌شده را وارد کنید.',
      child: Column(
        children: [
          TextFormField(
            autofocus: true,
            textAlign: TextAlign.center,
            keyboardType: TextInputType.number,
            maxLength: 6,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(letterSpacing: 10),
            decoration: const InputDecoration(
              hintText: '— — — — — —',
              counterText: '',
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const Expanded(child: Text('کد را دریافت نکردید؟')),
              TextButton(
                onPressed: () => showPreviewActionSheet(
                  context,
                  title: 'ارسال دوباره کد',
                  description:
                      'ارسال واقعی کد و محدودیت درخواست در نسخه ۰.۲ فعال می‌شود.',
                ),
                child: const Text('ارسال دوباره'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => resetFlow
                  ? context.push('/reset-password')
                  : context.push('/device-security'),
              child: const Text('تأیید و ادامه'),
            ),
          ),
        ],
      ),
    );
  }
}

class ResetPasswordScreen extends StatelessWidget {
  const ResetPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      title: 'رمز عبور جدید',
      subtitle: 'رمزی انتخاب کنید که در جای دیگری استفاده نکرده‌اید.',
      child: Column(
        children: [
          const LabeledField(label: 'رمز عبور جدید', icon: Icons.lock_reset_rounded),
          const SizedBox(height: 16),
          const LabeledField(label: 'تکرار رمز عبور', icon: Icons.verified_user_outlined),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => context.go('/login'),
              child: const Text('ذخیره رمز جدید'),
            ),
          ),
        ],
      ),
    );
  }
}

class DeviceSecurityScreen extends StatefulWidget {
  const DeviceSecurityScreen({super.key});

  @override
  State<DeviceSecurityScreen> createState() => _DeviceSecurityScreenState();
}

class _DeviceSecurityScreenState extends State<DeviceSecurityScreen> {
  bool biometric = false;
  bool remember = true;

  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      title: 'امنیت دستگاه',
      subtitle: 'تنظیمات ورود این دستگاه را مشخص کنید.',
      child: Column(
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: biometric,
            onChanged: (value) => setState(() => biometric = value),
            title: const Text('ورود با اثر انگشت یا قفل دستگاه'),
            subtitle: const Text('در صورت پشتیبانی دستگاه'),
          ),
          const Divider(),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: remember,
            onChanged: (value) => setState(() => remember = value),
            title: const Text('این دستگاه را به خاطر بسپار'),
            subtitle: const Text('نشست امن پس از بستن برنامه حفظ شود'),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => context.go('/store-setup'),
              child: const Text('ادامه تنظیم فروشگاه'),
            ),
          ),
        ],
      ),
    );
  }
}

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('شرایط استفاده')),
      body: const PageFrame(
        maxWidth: 760,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PreviewBanner(),
            SizedBox(height: 16),
            AppCard(
              child: Text(
                'متن حقوقی نهایی در نسخه تجاری و پس از بازبینی حقوقی درج می‌شود. این صفحه در نسخه ۰.۱ فقط ساختار خواندن، تیترها، فاصله‌گذاری و دسترس‌پذیری متن‌های طولانی را نمایش می‌دهد.',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
