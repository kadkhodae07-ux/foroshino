import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:foroshino/app/app.dart';

void main() {
  testWidgets('فروشینو starts on onboarding', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: ForoshinoApp()));
    await tester.pumpAndSettle();

    expect(find.text('فروشینو'), findsWidgets);
    expect(find.text('ساخت فروشگاه'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
