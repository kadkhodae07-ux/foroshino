import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:foroshino/app/app.dart';
import 'package:foroshino/app/router.dart';

void main() {
  testWidgets('seven version taps open admin authentication only', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: ForoshinoApp()));
    appRouter.go('/about');
    await tester.pumpAndSettle();

    final versionTile = find.text('نسخه برنامه');
    expect(versionTile, findsOneWidget);

    for (var index = 0; index < 7; index++) {
      await tester.tap(versionTile);
      await tester.pump(const Duration(milliseconds: 100));
    }
    await tester.pumpAndSettle();

    expect(find.text('احراز هویت مدیر کل'), findsOneWidget);
    expect(find.text('ورود امن'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
