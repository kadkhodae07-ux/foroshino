import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:foroshino/app/app.dart';
import 'package:foroshino/app/router.dart';

void main() {
  const routes = <String>[
    '/welcome',
    '/login',
    '/register',
    '/forgot-password',
    '/verify',
    '/reset-password',
    '/device-security',
    '/terms',
    '/store-setup',
    '/home',
    '/sales',
    '/orders',
    '/products',
    '/more',
    '/products/new',
    '/products/edit',
    '/products/details',
    '/barcode-tools?tab=scanner',
    '/barcode-tools?tab=generator',
    '/sale-confirmation',
    '/invoice-preview',
    '/orders/new',
    '/orders/details',
    '/customers',
    '/customers/new',
    '/customers/profile',
    '/customers/payment',
    '/inventory',
    '/inventory/operation?type=ورود%20موجودی',
    '/suppliers',
    '/suppliers/new',
    '/suppliers/profile',
    '/purchases/new',
    '/returns/new',
    '/expenses',
    '/expenses/new',
    '/expenses/details',
    '/reports',
    '/employees',
    '/employees/new',
    '/employees/profile',
    '/backup-sync',
    '/connected-devices',
    '/printer-setup',
    '/store-settings',
    '/settings',
    '/help',
    '/about',
    '/admin/login',
    '/admin',
    '/admin/section/stores',
  ];

  testWidgets('all UI routes render on a small Android phone without exceptions', (tester) async {
    tester.view.physicalSize = const Size(320, 640);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const ProviderScope(child: ForoshinoApp()));

    for (final route in routes) {
      appRouter.go(route);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));
      expect(
        tester.takeException(),
        isNull,
        reason: 'Route failed at 320×640: $route',
      );
    }
  });

  testWidgets('main navigation renders on a tablet without exceptions', (tester) async {
    tester.view.physicalSize = const Size(1024, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    appRouter.go('/home');
    await tester.pumpWidget(const ProviderScope(child: ForoshinoApp()));
    for (final route in const ['/home', '/sales', '/orders', '/products', '/more', '/admin']) {
      appRouter.go(route);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));
      expect(
        tester.takeException(),
        isNull,
        reason: 'Tablet route failed: $route',
      );
    }
  });
}
