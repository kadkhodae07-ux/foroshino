package com.foroshino.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
