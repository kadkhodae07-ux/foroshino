#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path
from xml.etree import ElementTree

try:
    import yaml
except ImportError:
    yaml = None

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
notes: list[str] = []


def check_balanced(path: Path) -> None:
    text = path.read_text(encoding='utf-8')
    stack: list[tuple[str, int, int]] = []
    pairs = {')': '(', ']': '[', '}': '{'}
    opens = set(pairs.values())
    i = 0
    line = 1
    col = 1
    state = 'code'
    quote = ''
    triple = False
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ''
        third = text[i + 2] if i + 2 < len(text) else ''
        if state == 'line_comment':
            if ch == '\n':
                state = 'code'
        elif state == 'block_comment':
            if ch == '*' and nxt == '/':
                state = 'code'
                i += 1
                col += 1
        elif state == 'string':
            if ch == '\\':
                i += 1
                col += 1
            elif triple and ch == quote and nxt == quote and third == quote:
                state = 'code'
                i += 2
                col += 2
            elif not triple and ch == quote:
                state = 'code'
        else:
            if ch == '/' and nxt == '/':
                state = 'line_comment'
                i += 1
                col += 1
            elif ch == '/' and nxt == '*':
                state = 'block_comment'
                i += 1
                col += 1
            elif ch in "'\"":
                quote = ch
                triple = nxt == ch and third == ch
                state = 'string'
                if triple:
                    i += 2
                    col += 2
            elif ch in opens:
                stack.append((ch, line, col))
            elif ch in pairs:
                if not stack or stack[-1][0] != pairs[ch]:
                    errors.append(f'{path.relative_to(ROOT)}:{line}:{col}: unmatched {ch}')
                    return
                stack.pop()
        if ch == '\n':
            line += 1
            col = 1
        else:
            col += 1
        i += 1
    if state in {'string', 'block_comment'}:
        errors.append(f'{path.relative_to(ROOT)}: unterminated {state}')
    if stack:
        ch, ln, cl = stack[-1]
        errors.append(f'{path.relative_to(ROOT)}:{ln}:{cl}: unclosed {ch}')


def check_relative_imports(path: Path) -> None:
    text = path.read_text(encoding='utf-8')
    for target in re.findall(r"^import\s+['\"]([^'\"]+)['\"];", text, flags=re.M):
        if target.startswith('.'):
            resolved = (path.parent / target).resolve()
            if not resolved.exists():
                errors.append(f'{path.relative_to(ROOT)}: missing import {target}')


for dart in sorted([*ROOT.glob('lib/**/*.dart'), *ROOT.glob('test/**/*.dart')]):
    check_balanced(dart)
    check_relative_imports(dart)

# Basic route integrity.
router = (ROOT / 'lib/app/router.dart').read_text(encoding='utf-8')
defined = set(re.findall(r"path:\s*'([^']+)'", router))
references: list[tuple[Path, str]] = []
for dart in ROOT.glob('lib/**/*.dart'):
    text = dart.read_text(encoding='utf-8')
    for route in re.findall(r"context\.(?:push|go)\(\s*'([^']+)'", text):
        references.append((dart, route.split('?')[0]))
for dart, route in references:
    if '$' in route or ':' in route:
        continue
    if route not in defined:
        errors.append(f'{dart.relative_to(ROOT)}: route reference not defined: {route}')

# Detect dead callbacks and development placeholders.
for dart in ROOT.glob('lib/**/*.dart'):
    text = dart.read_text(encoding='utf-8')
    for pattern, label in [
        (r'onPressed:\s*\(\)\s*\{\s*\}', 'empty onPressed'),
        (r'onTap:\s*\(\)\s*\{\s*\}', 'empty onTap'),
        (r'\bTODO\b|\bFIXME\b', 'TODO/FIXME'),
        (r'Lorem Ipsum', 'Lorem Ipsum'),
    ]:
        if re.search(pattern, text, flags=re.S):
            errors.append(f'{dart.relative_to(ROOT)}: {label}')

# XML and YAML parse checks.
for xml in ROOT.glob('android/**/*.xml'):
    try:
        ElementTree.parse(xml)
    except Exception as exc:
        errors.append(f'{xml.relative_to(ROOT)}: XML parse failed: {exc}')
if yaml:
    for yml in [ROOT / 'pubspec.yaml', ROOT / 'analysis_options.yaml', *ROOT.glob('.github/workflows/*.yml')]:
        try:
            yaml.safe_load(yml.read_text(encoding='utf-8'))
        except Exception as exc:
            errors.append(f'{yml.relative_to(ROOT)}: YAML parse failed: {exc}')

# Manifest identity and forbidden secret patterns.
manifest = (ROOT / 'android/app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
if 'android:label="فروشینو"' not in manifest:
    errors.append('Android manifest does not use the فروشینو label')
all_text = '\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p.suffix.lower() in {'.dart', '.yaml', '.yml', '.md', '.kt', '.kts', '.xml', '.properties', '.sh'})
secret_patterns = [r'sk-[A-Za-z0-9_-]{20,}', r'AKIA[0-9A-Z]{16}', r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----']
for pattern in secret_patterns:
    if re.search(pattern, all_text):
        errors.append(f'possible exposed secret matched {pattern}')

notes.append(f'Dart files: {len(list(ROOT.glob("lib/**/*.dart")))}')
notes.append(f'Dart source/test lines: {sum(len(p.read_text(encoding="utf-8").splitlines()) for p in [*ROOT.glob("lib/**/*.dart"), *ROOT.glob("test/**/*.dart")])}')
notes.append(f'Defined routes: {len(defined)}')
notes.append(f'Route references checked: {len(references)}')
notes.append('XML documents parsed successfully' if not any('XML parse' in e for e in errors) else 'XML errors found')
notes.append('YAML documents parsed successfully' if not any('YAML parse' in e for e in errors) else 'YAML errors found')

print('\n'.join(notes))
if errors:
    print('\nERRORS:')
    print('\n'.join(f'- {item}' for item in errors))
    sys.exit(1)
print('\nStatic validation passed.')
