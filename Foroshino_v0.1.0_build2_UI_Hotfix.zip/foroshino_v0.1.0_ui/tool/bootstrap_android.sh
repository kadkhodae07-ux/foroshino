#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required." >&2
  exit 1
fi

if [[ ! -f android/gradle/wrapper/gradle-wrapper.jar ]]; then
  tmp_dir="$(mktemp -d)"
  flutter create "$tmp_dir/wrapper_source" \
    --platforms=android \
    --project-name wrapper_source \
    --org com.example
  mkdir -p android/gradle/wrapper
  cp "$tmp_dir/wrapper_source/android/gradle/wrapper/gradle-wrapper.jar" \
    android/gradle/wrapper/gradle-wrapper.jar
  rm -rf "$tmp_dir"
fi

chmod +x android/gradlew
flutter pub get
dart format lib test
python3 tool/static_validate.py
flutter analyze
flutter test
