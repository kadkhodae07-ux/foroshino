import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:foroshino/app/app.dart';
import 'package:foroshino/app/router.dart';
import 'package:foroshino/app/state.dart';

void main() {
  testWidgets('capture the main Version 0.1 UI review set', (tester) async {
    const captureEnabled = bool.fromEnvironment('CAPTURE_SCREENSHOTS');
    if (!captureEnabled) {
      return;
    }

    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    appRouter.go('/welcome');
    final container = ProviderContainer();
    addTearDown(container.dispose);
    await tester.pumpWidget(
      UncontrolledProviderScope(
        container: container,
        child: const ForoshinoApp(),
      ),
    );

    final captures = <(String, String)>[
      ('01-onboarding', '/welcome'),
      ('02-login', '/login'),
      ('03-store-setup', '/store-setup'),
      ('04-home', '/home'),
      ('05-products', '/products'),
      ('06-product-form', '/products/new'),
      ('07-barcode-scanner', '/barcode-tools?tab=scanner'),
      ('08-sales', '/sales'),
      ('09-invoice', '/invoice-preview'),
      ('10-orders', '/orders'),
      ('11-more', '/more'),
      ('12-admin-login', '/admin/login'),
      ('13-admin-dashboard', '/admin'),
    ];

    for (final capture in captures) {
      appRouter.go(capture.$2);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));
      await _capture(tester, capture.$1);
    }

    container.read(themeModeProvider.notifier).setMode(ThemeMode.dark);
    appRouter.go('/home');
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 500));
    await _capture(tester, '14-home-dark');
  });
}

Future<void> _capture(WidgetTester tester, String name) async {
  final element = find.byKey(const ValueKey('app-screenshot-boundary')).evaluate().single;
  final image = await captureImage(element);
  final data = await image.toByteData(format: ui.ImageByteFormat.png);
  image.dispose();
  if (data == null) {
    throw StateError('Could not encode screenshot $name');
  }
  await tester.runAsync(() async {
    final directory = Directory('screenshots');
    await directory.create(recursive: true);
    await File('${directory.path}/$name.png').writeAsBytes(data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes));
  });
}
