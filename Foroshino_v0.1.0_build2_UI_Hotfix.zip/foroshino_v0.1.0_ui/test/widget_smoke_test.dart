import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:foroshino/app/app.dart';
import 'package:foroshino/app/router.dart';

void main() {
  testWidgets('فروشینو starts on onboarding', (tester) async {
    appRouter.go('/welcome');
    await tester.pumpWidget(const ProviderScope(child: ForoshinoApp()));
    await tester.pumpAndSettle();

    expect(find.text('فروشینو'), findsWidgets);
    expect(find.text('ادامه'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
