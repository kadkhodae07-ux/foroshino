import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../app/theme.dart';
import '../../app/widgets.dart';

class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  bool biometric = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ورود مدیریت سامانه')),
      body: PageFrame(
        maxWidth: 560,
        child: Column(
          children: [
            Container(
              width: 78,
              height: 78,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.errorContainer,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Icon(
                Icons.admin_panel_settings_outlined,
                size: 40,
                color: Theme.of(context).colorScheme.onErrorContainer,
              ),
            ),
            const SizedBox(height: 18),
            Text('احراز هویت مدیر کل', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text(
              'هفت بار لمس نسخه فقط این مسیر را باز می‌کند و هیچ دسترسی مدیریتی اعطا نمی‌کند.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
            const SizedBox(height: 20),
            AppCard(
              child: Column(
                children: [
                  const LabeledField(
                    label: 'حساب مدیر کل',
                    hint: 'ایمیل یا شناسه مدیر',
                    icon: Icons.person_outline_rounded,
                  ),
                  const SizedBox(height: 14),
                  const LabeledField(
                    label: 'رمز عبور',
                    hint: 'رمز عبور امن',
                    icon: Icons.lock_outline_rounded,
                  ),
                  const SizedBox(height: 14),
                  const LabeledField(
                    label: 'PIN امنیتی',
                    hint: 'در صورت فعال بودن',
                    icon: Icons.pin_outlined,
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 10),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: biometric,
                    onChanged: (value) => setState(() => biometric = value),
                    title: const Text('تأیید با قفل دستگاه'),
                    subtitle: const Text('پس از اعتبارسنجی سمت سرور'),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => showPreviewActionSheet(
                        context,
                        title: 'احراز هویت مدیر',
                        description:
                            'اعتبارسنجی نقش مدیر کل، محدودیت تلاش و توکن امن در نسخه ۰.۵ فعال می‌شود.',
                      ),
                      icon: const Icon(Icons.verified_user_outlined),
                      label: const Text('ورود امن'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => _openPreview(context),
                      child: const Text('پیش‌نمایش رابط پنل مدیریت'),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.errorContainer.withValues(alpha: .45),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.security_rounded, color: Theme.of(context).colorScheme.error),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      'پیش‌نمایش زیر فقط برای بازبینی UI نسخه ۰.۱ است و نشست مدیریتی، مجوز یا دسترسی به داده خصوصی ایجاد نمی‌کند.',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openPreview(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.visibility_outlined),
        title: const Text('پیش‌نمایش رابط مدیریت'),
        content: const Text(
          'این مسیر تنها صفحات بصری را نمایش می‌دهد و نباید به‌عنوان ورود موفق یا دسترسی مدیر در نظر گرفته شود.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('انصراف'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('نمایش پیش‌نمایش'),
          ),
        ],
      ),
    );
    if (result == true && context.mounted) context.push('/admin');
  }
}

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  static const sections = [
    _AdminSection('فروشگاه‌ها', Icons.store_mall_directory_outlined, 'stores'),
    _AdminSection('کاربران', Icons.group_outlined, 'users'),
    _AdminSection('اشتراک‌ها', Icons.workspace_premium_outlined, 'subscriptions'),
    _AdminSection('دستگاه‌ها', Icons.devices_outlined, 'devices'),
    _AdminSection('نسخه‌های برنامه', Icons.new_releases_outlined, 'releases'),
    _AdminSection('اعلان‌های سراسری', Icons.campaign_outlined, 'notifications'),
    _AdminSection('تیکت‌های پشتیبانی', Icons.support_agent_outlined, 'tickets'),
    _AdminSection('گزارش خطا', Icons.bug_report_outlined, 'errors'),
    _AdminSection('سلامت همگام‌سازی', Icons.sync_problem_outlined, 'sync'),
    _AdminSection('مصرف فضای ذخیره‌سازی', Icons.storage_outlined, 'storage'),
    _AdminSection('لاگ‌های امنیتی', Icons.security_outlined, 'security'),
    _AdminSection('تنظیمات سراسری', Icons.tune_rounded, 'settings'),
    _AdminSection('قالب‌های فاکتور', Icons.receipt_long_outlined, 'invoice-templates'),
    _AdminSection('روش‌های پرداخت', Icons.credit_card_outlined, 'payment-methods'),
    _AdminSection('واحدها', Icons.straighten_rounded, 'units'),
    _AdminSection('پیام‌های سیستمی', Icons.message_outlined, 'messages'),
    _AdminSection('پشتیبان‌گیری', Icons.cloud_sync_outlined, 'backups'),
    _AdminSection('صفحات حقوقی', Icons.gavel_outlined, 'legal'),
    _AdminSection('برندینگ برنامه', Icons.palette_outlined, 'branding'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('مدیریت کل فروشینو'),
            Text('پیش‌نمایش رابط — بدون نشست مدیریتی', style: TextStyle(fontSize: 11)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'قفل پنل',
            onPressed: () => context.pop(),
            icon: const Icon(Icons.lock_outline_rounded),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: PageFrame(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.errorContainer,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  Icon(Icons.visibility_outlined, color: Theme.of(context).colorScheme.onErrorContainer),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'این محیط فقط پیش‌نمایش UI است؛ نقش مدیر، توکن و مجوز سمت سرور ایجاد نشده است.',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onErrorContainer,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const ResponsiveGrid(
              minItemWidth: 220,
              childAspectRatio: 1.9,
              children: [
                MetricCard(
                  icon: Icons.storefront_outlined,
                  title: 'فروشگاه‌های فعال',
                  value: '—',
                  caption: 'داده سراسری متصل نیست',
                ),
                MetricCard(
                  icon: Icons.people_alt_outlined,
                  title: 'کاربران',
                  value: '—',
                  caption: 'داده سراسری متصل نیست',
                ),
                MetricCard(
                  icon: Icons.sync_problem_outlined,
                  title: 'خطاهای همگام‌سازی',
                  value: '—',
                  caption: 'سرویس همگام‌سازی فعال نیست',
                ),
                MetricCard(
                  icon: Icons.support_agent_outlined,
                  title: 'تیکت‌های باز',
                  value: '—',
                  caption: 'سامانه پشتیبانی فعال نیست',
                ),
              ],
            ),
            const SizedBox(height: 20),
            const SectionHeader(title: 'بخش‌های مدیریت کل'),
            const SizedBox(height: 12),
            ResponsiveGrid(
              minItemWidth: 260,
              childAspectRatio: 3.1,
              children: sections
                  .map(
                    (section) => QuickActionTile(
                      icon: section.icon,
                      label: section.label,
                      onTap: () => context.push('/admin/section/${section.key}'),
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class AdminSectionScreen extends StatelessWidget {
  const AdminSectionScreen({super.key, required this.sectionKey});

  final String sectionKey;

  static const meta = <String, (String, IconData, String)> {
    'stores': ('فروشگاه‌ها', Icons.store_mall_directory_outlined, 'جست‌وجو، وضعیت اشتراک، تعلیق و محدودیت‌ها'),
    'users': ('کاربران', Icons.group_outlined, 'حساب‌ها، نقش‌ها، وضعیت و دستگاه‌های مرتبط'),
    'subscriptions': ('اشتراک‌ها', Icons.workspace_premium_outlined, 'پلن‌ها، تمدید، هدیه و محدودیت‌ها'),
    'devices': ('دستگاه‌ها', Icons.devices_outlined, 'ثبت دستگاه، نسخه، آخرین فعالیت و لغو دسترسی'),
    'releases': ('نسخه‌های برنامه', Icons.new_releases_outlined, 'نسخه جدید، حداقل نسخه و انتشار اجباری'),
    'notifications': ('اعلان‌های سراسری', Icons.campaign_outlined, 'ساخت، زمان‌بندی و گزارش ارسال اعلان'),
    'tickets': ('تیکت‌های پشتیبانی', Icons.support_agent_outlined, 'صف تیکت‌ها، اولویت و پاسخ مدیر'),
    'errors': ('گزارش خطا', Icons.bug_report_outlined, 'خطاهای برنامه، نسخه، دستگاه و وضعیت رسیدگی'),
    'sync': ('سلامت همگام‌سازی', Icons.sync_problem_outlined, 'عملیات ناموفق، تعارض‌ها و تلاش دوباره'),
    'storage': ('فضای ذخیره‌سازی', Icons.storage_outlined, 'مصرف فایل، پشتیبان و محدودیت پلن'),
    'security': ('لاگ‌های امنیتی', Icons.security_outlined, 'ورود، قفل، لغو نشست و عملیات حساس'),
    'settings': ('تنظیمات سراسری', Icons.tune_rounded, 'مقادیر عمومی سامانه و سیاست‌های اجرایی'),
    'invoice-templates': ('قالب‌های فاکتور', Icons.receipt_long_outlined, 'قالب‌های استاندارد و تنظیمات قابل انتشار'),
    'payment-methods': ('روش‌های پرداخت', Icons.credit_card_outlined, 'تعریف روش‌ها و فعال‌سازی سراسری'),
    'units': ('واحدها', Icons.straighten_rounded, 'واحدهای پیش‌فرض محصول و وزن'),
    'messages': ('پیام‌های سیستمی', Icons.message_outlined, 'متن‌های آماده و پیام‌های نگهداری'),
    'backups': ('پشتیبان‌گیری', Icons.cloud_sync_outlined, 'سیاست، وضعیت و بازیابی کنترل‌شده'),
    'legal': ('صفحات حقوقی', Icons.gavel_outlined, 'حریم خصوصی، شرایط استفاده و حذف حساب'),
    'branding': ('برندینگ برنامه', Icons.palette_outlined, 'نام، رنگ‌ها، نشان و دارایی‌های عمومی'),
  };

  @override
  Widget build(BuildContext context) {
    final data = meta[sectionKey] ?? ('بخش مدیریت', Icons.admin_panel_settings_outlined, 'ساختار رابط مدیریت');
    return Scaffold(
      appBar: AppBar(title: Text(data.$1)),
      body: PageFrame(
        maxWidth: 980,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.secondary.withValues(alpha: .14),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Row(
                children: [
                  Icon(Icons.visibility_outlined, color: AppColors.secondary),
                  SizedBox(width: 10),
                  Expanded(child: Text('پیش‌نمایش UI؛ هیچ عملیات مدیریتی واقعی انجام نمی‌شود.')),
                ],
              ),
            ),
            const SizedBox(height: 16),
            AppCard(
              child: Row(
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(data.$2, color: Theme.of(context).colorScheme.primary),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(data.$1, style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(height: 4),
                        Text(
                          data.$3,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: Theme.of(context).colorScheme.onSurfaceVariant,
                              ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              decoration: const InputDecoration(
                hintText: 'جست‌وجو و فیلتر',
                prefixIcon: Icon(Icons.search_rounded),
                suffixIcon: Icon(Icons.filter_list_rounded),
              ),
            ),
            const SizedBox(height: 14),
            const EmptyState(
              icon: Icons.inbox_outlined,
              title: 'داده مدیریتی متصل نیست',
              message:
                  'این بخش در نسخه ۰.۵ به API امن، مجوز سمت سرور و ثبت کامل Audit Log متصل می‌شود.',
            ),
          ],
        ),
      ),
    );
  }
}

class _AdminSection {
  const _AdminSection(this.label, this.icon, this.key);
  final String label;
  final IconData icon;
  final String key;
}
