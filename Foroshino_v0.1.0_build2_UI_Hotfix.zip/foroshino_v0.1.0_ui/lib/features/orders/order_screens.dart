import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../app/widgets.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('سفارش‌ها'),
        actions: [
          IconButton(
            tooltip: 'فیلتر',
            onPressed: () => _showFilter(context),
            icon: const Icon(Icons.filter_list_rounded),
          ),
          const SizedBox(width: 6),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push('/orders/new'),
        icon: const Icon(Icons.add_rounded),
        label: const Text('سفارش جدید'),
      ),
      body: PageFrame(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              decoration: const InputDecoration(
                hintText: 'جست‌وجوی شماره سفارش یا نام مشتری',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('همه')),
                  ButtonSegment(value: 1, label: Text('در انتظار')),
                  ButtonSegment(value: 2, label: Text('آماده ارسال')),
                  ButtonSegment(value: 3, label: Text('ارسال‌شده')),
                  ButtonSegment(value: 4, label: Text('تحویل‌شده')),
                ],
                selected: {tab},
                onSelectionChanged: (value) => setState(() => tab = value.first),
              ),
            ),
            const SizedBox(height: 16),
            const PreviewBanner(compact: true),
            const SizedBox(height: 16),
            EmptyState(
              icon: Icons.local_shipping_outlined,
              title: tab == 0 ? 'هنوز سفارشی ثبت نشده است' : 'سفارشی در این وضعیت وجود ندارد',
              message:
                  'برای سفارش حضوری، تلفنی یا شبکه‌های اجتماعی یک سفارش جدید بسازید.',
              primaryLabel: 'ساخت سفارش',
              onPrimary: () => context.push('/orders/new'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showFilter(BuildContext context) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('فیلتر سفارش‌ها', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 18),
              const LabeledField(label: 'بازه تاریخ', icon: Icons.date_range_outlined),
              const SizedBox(height: 14),
              const LabeledField(label: 'روش ارسال', icon: Icons.local_shipping_outlined),
              const SizedBox(height: 14),
              const LabeledField(label: 'وضعیت پرداخت', icon: Icons.payments_outlined),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('اعمال فیلتر'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NewOrderScreen extends StatefulWidget {
  const NewOrderScreen({super.key});

  @override
  State<NewOrderScreen> createState() => _NewOrderScreenState();
}

class _NewOrderScreenState extends State<NewOrderScreen> {
  int step = 0;
  bool shipping = true;

  @override
  Widget build(BuildContext context) {
    final steps = [
      _CustomerOrderStep(onChoose: () => context.push('/customers')),
      const _OrderItemsStep(),
      _DeliveryOrderStep(
        shipping: shipping,
        onShippingChanged: (value) => setState(() => shipping = value),
      ),
      const _OrderReviewStep(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('سفارش جدید')),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
              child: Row(
                children: List.generate(
                  steps.length,
                  (index) => Expanded(
                    child: Container(
                      height: 5,
                      margin: EdgeInsets.only(left: index == steps.length - 1 ? 0 : 6),
                      decoration: BoxDecoration(
                        color: index <= step
                            ? Theme.of(context).colorScheme.primary
                            : Theme.of(context).colorScheme.outlineVariant,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: PageFrame(
                maxWidth: 820,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  child: KeyedSubtree(key: ValueKey(step), child: steps[step]),
                ),
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
                child: Row(
                  children: [
                    if (step > 0)
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => setState(() => step--),
                          child: const Text('مرحله قبل'),
                        ),
                      ),
                    if (step > 0) const SizedBox(width: 10),
                    Expanded(
                      flex: 2,
                      child: FilledButton(
                        onPressed: () {
                          if (step < steps.length - 1) {
                            setState(() => step++);
                          } else {
                            showPreviewActionSheet(
                              context,
                              title: 'ثبت سفارش',
                              description:
                                  'در نسخه ۰.۱ سفارش واقعی، رزرو موجودی یا پیام مشتری ایجاد نمی‌شود.',
                            );
                          }
                        },
                        child: Text(step == steps.length - 1 ? 'ثبت سفارش' : 'ادامه'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CustomerOrderStep extends StatelessWidget {
  const _CustomerOrderStep({required this.onChoose});

  final VoidCallback onChoose;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader(
          title: 'مشتری سفارش',
          subtitle: 'برای ثبت نشانی، پیگیری و بدهی احتمالی، مشتری را انتخاب کنید.',
        ),
        const SizedBox(height: 16),
        AppCard(
          onTap: onChoose,
          child: const ListTile(
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(child: Icon(Icons.person_add_alt_1_outlined)),
            title: Text('انتخاب یا افزودن مشتری'),
            subtitle: Text('هنوز مشتری انتخاب نشده است'),
            trailing: Icon(Icons.arrow_back_ios_new_rounded, size: 16),
          ),
        ),
        const SizedBox(height: 14),
        const LabeledField(
          label: 'یادداشت مشتری',
          hint: 'توضیحی که در سفارش یا پیام مشتری دیده می‌شود',
          icon: Icons.chat_bubble_outline_rounded,
          maxLines: 3,
        ),
      ],
    );
  }
}

class _OrderItemsStep extends StatelessWidget {
  const _OrderItemsStep();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader(
          title: 'اقلام سفارش',
          subtitle: 'محصول را جست‌وجو یا بارکد آن را اسکن کنید.',
        ),
        const SizedBox(height: 14),
        TextField(
          decoration: InputDecoration(
            hintText: 'جست‌وجوی محصول',
            prefixIcon: const Icon(Icons.search_rounded),
            suffixIcon: IconButton(
              onPressed: () => context.push('/barcode-tools?tab=scanner'),
              icon: const Icon(Icons.qr_code_scanner_rounded),
            ),
          ),
        ),
        const SizedBox(height: 14),
        const EmptyState(
          icon: Icons.shopping_basket_outlined,
          title: 'اقلام سفارش خالی است',
          message: 'پس از افزودن محصول، تعداد، قیمت، تخفیف و جمع هر ردیف نمایش داده می‌شود.',
        ),
      ],
    );
  }
}

class _DeliveryOrderStep extends StatelessWidget {
  const _DeliveryOrderStep({
    required this.shipping,
    required this.onShippingChanged,
  });

  final bool shipping;
  final ValueChanged<bool> onShippingChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader(title: 'تحویل و ارسال'),
        const SizedBox(height: 14),
        AppCard(
          child: Column(
            children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: shipping,
                onChanged: onShippingChanged,
                title: const Text('سفارش نیاز به ارسال دارد'),
              ),
              if (shipping) ...[
                const Divider(),
                const LabeledField(
                  label: 'نشانی تحویل',
                  hint: 'انتخاب از نشانی‌های مشتری یا افزودن نشانی جدید',
                  icon: Icons.location_on_outlined,
                  maxLines: 2,
                ),
                const SizedBox(height: 14),
                const LabeledField(
                  label: 'روش ارسال',
                  hint: 'پیک، پست، تحویل حضوری یا سایر',
                  icon: Icons.local_shipping_outlined,
                ),
                const SizedBox(height: 14),
                const LabeledField(
                  label: 'هزینه ارسال',
                  hint: '۰',
                  icon: Icons.payments_outlined,
                  keyboardType: TextInputType.number,
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _OrderReviewStep extends StatelessWidget {
  const _OrderReviewStep();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SectionHeader(
          title: 'بررسی نهایی',
          subtitle: 'اطلاعات ناقص با پیام روشن مشخص می‌شود و داده‌ای بدون تأیید ثبت نخواهد شد.',
        ),
        SizedBox(height: 14),
        PreviewBanner(),
        SizedBox(height: 14),
        AppCard(
          child: Column(
            children: [
              _OrderReviewLine(label: 'مشتری', value: 'انتخاب نشده'),
              Divider(),
              _OrderReviewLine(label: 'تعداد اقلام', value: '۰'),
              _OrderReviewLine(label: 'روش تحویل', value: '—'),
              _OrderReviewLine(label: 'جمع نهایی', value: '۰ تومان'),
            ],
          ),
        ),
      ],
    );
  }
}

class _OrderReviewLine extends StatelessWidget {
  const _OrderReviewLine({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Text(value, style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    );
  }
}

class OrderDetailsScreen extends StatelessWidget {
  const OrderDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final statuses = [
      ('ثبت‌شده', Icons.receipt_long_outlined),
      ('در انتظار پرداخت', Icons.schedule_rounded),
      ('در حال آماده‌سازی', Icons.inventory_2_outlined),
      ('آماده ارسال', Icons.local_shipping_outlined),
      ('تحویل‌شده', Icons.check_circle_outline_rounded),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('جزئیات سفارش'),
        actions: [
          IconButton(
            tooltip: 'اشتراک پیام وضعیت',
            onPressed: () => showPreviewActionSheet(
              context,
              title: 'پیام وضعیت سفارش',
              description:
                  'در نسخه عملکردی، متن آماده از طریق Share Sheet اندروید و با اقدام مستقیم کاربر ارسال می‌شود.',
            ),
            icon: const Icon(Icons.share_outlined),
          ),
        ],
      ),
      body: PageFrame(
        maxWidth: 900,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const PreviewBanner(compact: true),
            const SizedBox(height: 16),
            AppCard(
              child: Column(
                children: [
                  const ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(child: Icon(Icons.local_shipping_outlined)),
                    title: Text('شماره سفارش: —'),
                    subtitle: Text('هیچ سفارش واقعی انتخاب نشده است'),
                    trailing: Chip(label: Text('بدون وضعیت')),
                  ),
                  const Divider(),
                  ...statuses.asMap().entries.map(
                        (entry) => _TimelineRow(
                          title: entry.value.$1,
                          icon: entry.value.$2,
                          active: entry.key == 0,
                          last: entry.key == statuses.length - 1,
                        ),
                      ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const SectionHeader(title: 'اطلاعات سفارش'),
            const SizedBox(height: 12),
            const AppCard(
              child: Column(
                children: [
                  _OrderReviewLine(label: 'مشتری', value: '—'),
                  _OrderReviewLine(label: 'نشانی', value: '—'),
                  _OrderReviewLine(label: 'روش ارسال', value: '—'),
                  _OrderReviewLine(label: 'کد رهگیری', value: '—'),
                  _OrderReviewLine(label: 'مبلغ', value: '۰ تومان'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TimelineRow extends StatelessWidget {
  const _TimelineRow({
    required this.title,
    required this.icon,
    required this.active,
    required this.last,
  });

  final String title;
  final IconData icon;
  final bool active;
  final bool last;

  @override
  Widget build(BuildContext context) {
    final color = active
        ? Theme.of(context).colorScheme.primary
        : Theme.of(context).colorScheme.outlineVariant;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 42,
          child: Column(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                child: Icon(icon, size: 17, color: active ? Colors.white : Colors.black54),
              ),
              if (!last) Container(width: 2, height: 36, color: color),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(top: 5),
            child: Text(
              title,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: active
                        ? Theme.of(context).colorScheme.onSurface
                        : Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ),
        ),
      ],
    );
  }
}
