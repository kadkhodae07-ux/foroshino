import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../app/widgets.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('فروشینو', style: Theme.of(context).textTheme.titleLarge),
            Text(
              'داشبورد فروشگاه',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'جست‌وجو',
            onPressed: () => _showGlobalSearch(context),
            icon: const Icon(Icons.search_rounded),
          ),
          IconButton(
            tooltip: 'اعلان‌ها',
            onPressed: () => showPreviewActionSheet(
              context,
              title: 'اعلان‌های فروشگاه',
              description:
                  'در این نسخه فقط ساختار اعلان‌ها آماده شده و هیچ اعلان تجاری ساختگی نمایش داده نمی‌شود.',
            ),
            icon: const Badge(child: Icon(Icons.notifications_none_rounded)),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: PageFrame(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const PreviewBanner(),
            const SizedBox(height: 18),
            const SectionHeader(
              title: 'امروز',
              subtitle: 'تا زمانی که داده واقعی ثبت نشود، آمار با خط تیره نمایش داده می‌شود.',
            ),
            const SizedBox(height: 12),
            const ResponsiveGrid(
              minItemWidth: 220,
              childAspectRatio: 1.75,
              children: [
                MetricCard(
                  icon: Icons.payments_outlined,
                  title: 'فروش امروز',
                  value: '—',
                  caption: 'هنوز فروشی ثبت نشده است',
                ),
                MetricCard(
                  icon: Icons.shopping_bag_outlined,
                  title: 'سفارش‌های امروز',
                  value: '—',
                  caption: 'بدون سفارش ثبت‌شده',
                ),
                MetricCard(
                  icon: Icons.pending_actions_outlined,
                  title: 'در انتظار پردازش',
                  value: '—',
                  caption: 'صف سفارش خالی است',
                ),
                MetricCard(
                  icon: Icons.trending_up_rounded,
                  title: 'سود تقریبی',
                  value: '—',
                  caption: 'پس از ثبت داده واقعی محاسبه می‌شود',
                ),
              ],
            ),
            const SizedBox(height: 24),
            const SectionHeader(title: 'دسترسی سریع'),
            const SizedBox(height: 12),
            ResponsiveGrid(
              minItemWidth: 250,
              childAspectRatio: 3.15,
              children: [
                QuickActionTile(
                  icon: Icons.point_of_sale_rounded,
                  label: 'فروش جدید',
                  onTap: () => context.go('/sales'),
                ),
                QuickActionTile(
                  icon: Icons.add_shopping_cart_rounded,
                  label: 'سفارش جدید',
                  onTap: () => context.push('/orders/new'),
                ),
                QuickActionTile(
                  icon: Icons.add_box_outlined,
                  label: 'افزودن محصول',
                  onTap: () => context.push('/products/new'),
                ),
                QuickActionTile(
                  icon: Icons.qr_code_scanner_rounded,
                  label: 'اسکن بارکد',
                  onTap: () => context.push('/barcode-tools?tab=scanner'),
                ),
              ],
            ),
            const SizedBox(height: 24),
            LayoutBuilder(
              builder: (context, constraints) {
                final wide = constraints.maxWidth >= 820;
                final lowStock = EmptyState(
                  icon: Icons.inventory_2_outlined,
                  title: 'محصول کم‌موجودی ندارید',
                  message:
                      'پس از تعریف محصول و حداقل موجودی، هشدارهای واقعی اینجا نمایش داده می‌شوند.',
                  primaryLabel: 'افزودن محصول',
                  onPrimary: () => context.push('/products/new'),
                );
                final debt = EmptyState(
                  icon: Icons.account_balance_wallet_outlined,
                  title: 'بدهی ثبت‌شده‌ای وجود ندارد',
                  message:
                      'بدهی مشتریان فقط بر پایه فروش و پرداخت واقعی محاسبه خواهد شد.',
                  primaryLabel: 'مشاهده مشتریان',
                  onPrimary: () => context.push('/customers'),
                );
                if (wide) {
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: lowStock),
                      const SizedBox(width: 14),
                      Expanded(child: debt),
                    ],
                  );
                }
                return Column(
                  children: [
                    lowStock,
                    const SizedBox(height: 14),
                    debt,
                  ],
                );
              },
            ),
            const SizedBox(height: 24),
            const SectionHeader(
              title: 'وضعیت‌های رابط',
              subtitle: 'الگوهای مشترک برای بارگذاری، آفلاین، هشدار و خطا.',
            ),
            const SizedBox(height: 12),
            const StateShowcase(),
          ],
        ),
      ),
    );
  }

  Future<void> _showGlobalSearch(BuildContext context) {
    return showSearch<void>(context: context, delegate: _ForoshinoSearchDelegate());
  }
}

class _ForoshinoSearchDelegate extends SearchDelegate<void> {
  @override
  String get searchFieldLabel => 'جست‌وجوی محصول، مشتری یا سفارش';

  @override
  List<Widget>? buildActions(BuildContext context) => [
        if (query.isNotEmpty)
          IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear_rounded)),
      ];

  @override
  Widget? buildLeading(BuildContext context) => IconButton(
        onPressed: () => close(context, null),
        icon: const Icon(Icons.arrow_forward_rounded),
      );

  @override
  Widget buildResults(BuildContext context) => _empty(context);

  @override
  Widget buildSuggestions(BuildContext context) => _empty(context);

  Widget _empty(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: EmptyState(
        icon: Icons.search_off_rounded,
        title: query.isEmpty ? 'عبارت موردنظر را وارد کنید' : 'نتیجه‌ای وجود ندارد',
        message: query.isEmpty
            ? 'جست‌وجوی یکپارچه در نسخه‌های عملکردی به داده واقعی متصل می‌شود.'
            : 'حساب جدید فاقد داده ساختگی است؛ پس نتیجه‌ای نمایش داده نمی‌شود.',
      ),
    );
  }
}
