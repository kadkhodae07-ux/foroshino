import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../features/admin/admin_screens.dart';
import '../features/auth/auth_screens.dart';
import '../features/home/home_screen.dart';
import '../features/more/more_screens.dart';
import '../features/more/operation_screens.dart';
import '../features/onboarding/onboarding.dart';
import '../features/orders/order_screens.dart';
import '../features/products/product_screens.dart';
import '../features/sales/sales_screens.dart';
import '../features/setup/store_setup.dart';
import '../features/shell/main_shell.dart';

final rootNavigatorKey = GlobalKey<NavigatorState>();

final GoRouter appRouter = GoRouter(
  navigatorKey: rootNavigatorKey,
  initialLocation: '/welcome',
  routes: [
    GoRoute(path: '/welcome', builder: (context, state) => const OnboardingScreen()),
    GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
    GoRoute(path: '/register', builder: (context, state) => const RegisterScreen()),
    GoRoute(
      path: '/forgot-password',
      builder: (context, state) => const ForgotPasswordScreen(),
    ),
    GoRoute(
      path: '/verify',
      builder: (context, state) => VerificationScreen(
        resetFlow: state.uri.queryParameters['flow'] == 'reset',
      ),
    ),
    GoRoute(
      path: '/reset-password',
      builder: (context, state) => const ResetPasswordScreen(),
    ),
    GoRoute(
      path: '/device-security',
      builder: (context, state) => const DeviceSecurityScreen(),
    ),
    GoRoute(path: '/terms', builder: (context, state) => const TermsScreen()),
    GoRoute(
      path: '/store-setup',
      builder: (context, state) => const StoreSetupScreen(),
    ),
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) => MainShell(navigationShell: navigationShell),
      branches: [
        StatefulShellBranch(
          routes: [
            GoRoute(path: '/home', builder: (context, state) => const HomeScreen()),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(path: '/sales', builder: (context, state) => const SalesScreen()),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(path: '/orders', builder: (context, state) => const OrdersScreen()),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(path: '/products', builder: (context, state) => const ProductsScreen()),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(path: '/more', builder: (context, state) => const MoreScreen()),
          ],
        ),
      ],
    ),
    GoRoute(
      path: '/products/new',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const ProductFormScreen(),
    ),
    GoRoute(
      path: '/products/edit',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const ProductFormScreen(editing: true),
    ),
    GoRoute(
      path: '/products/details',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const ProductDetailsScreen(),
    ),
    GoRoute(
      path: '/barcode-tools',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) {
        final tab = state.uri.queryParameters['tab'];
        return BarcodeToolsScreen(initialTab: tab == 'scanner' ? 0 : 1);
      },
    ),
    GoRoute(
      path: '/sale-confirmation',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const SaleConfirmationScreen(),
    ),
    GoRoute(
      path: '/invoice-preview',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const InvoicePreviewScreen(),
    ),
    GoRoute(
      path: '/orders/new',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const NewOrderScreen(),
    ),
    GoRoute(
      path: '/orders/details',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const OrderDetailsScreen(),
    ),
    GoRoute(path: '/customers', builder: (context, state) => const CustomersScreen()),
    GoRoute(
      path: '/customers/new',
      builder: (context, state) => const CustomerFormScreen(),
    ),
    GoRoute(
      path: '/customers/profile',
      builder: (context, state) => const CustomerProfileScreen(),
    ),
    GoRoute(
      path: '/customers/payment',
      builder: (context, state) => const CustomerPaymentScreen(),
    ),
    GoRoute(path: '/inventory', builder: (context, state) => const InventoryScreen()),
    GoRoute(
      path: '/inventory/operation',
      builder: (context, state) => StockOperationScreen(
        operationType: state.uri.queryParameters['type'] ?? 'عملیات موجودی',
      ),
    ),
    GoRoute(path: '/suppliers', builder: (context, state) => const SuppliersScreen()),
    GoRoute(
      path: '/suppliers/new',
      builder: (context, state) => const SupplierFormScreen(),
    ),
    GoRoute(
      path: '/suppliers/profile',
      builder: (context, state) => const SupplierProfileScreen(),
    ),
    GoRoute(
      path: '/purchases/new',
      builder: (context, state) => const PurchaseInvoiceScreen(),
    ),
    GoRoute(
      path: '/returns/new',
      builder: (context, state) => const ReturnFormScreen(),
    ),
    GoRoute(path: '/expenses', builder: (context, state) => const ExpensesScreen()),
    GoRoute(
      path: '/expenses/new',
      builder: (context, state) => const ExpenseFormScreen(),
    ),
    GoRoute(
      path: '/expenses/details',
      builder: (context, state) => const ExpenseDetailsScreen(),
    ),
    GoRoute(path: '/reports', builder: (context, state) => const ReportsScreen()),
    GoRoute(path: '/employees', builder: (context, state) => const EmployeesScreen()),
    GoRoute(
      path: '/employees/new',
      builder: (context, state) => const EmployeeFormScreen(),
    ),
    GoRoute(
      path: '/employees/profile',
      builder: (context, state) => const EmployeeProfileScreen(),
    ),
    GoRoute(
      path: '/backup-sync',
      builder: (context, state) => const BackupSyncScreen(),
    ),
    GoRoute(
      path: '/connected-devices',
      builder: (context, state) => const ConnectedDevicesScreen(),
    ),
    GoRoute(
      path: '/printer-setup',
      builder: (context, state) => const PrinterSetupScreen(),
    ),
    GoRoute(
      path: '/store-settings',
      builder: (context, state) => const StoreSettingsScreen(),
    ),
    GoRoute(path: '/settings', builder: (context, state) => const SettingsScreen()),
    GoRoute(path: '/help', builder: (context, state) => const HelpScreen()),
    GoRoute(path: '/about', builder: (context, state) => const AboutScreen()),
    GoRoute(
      path: '/admin/login',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const AdminLoginScreen(),
    ),
    GoRoute(
      path: '/admin',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const AdminDashboardScreen(),
    ),
    GoRoute(
      path: '/admin/section/:key',
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => AdminSectionScreen(
        sectionKey: state.pathParameters['key'] ?? '',
      ),
    ),
  ],
  errorBuilder: (context, state) => Scaffold(
    appBar: AppBar(title: const Text('صفحه پیدا نشد')),
    body: Center(
      child: FilledButton(
        onPressed: () => context.go('/home'),
        child: const Text('بازگشت به خانه'),
      ),
    ),
  ),
);
