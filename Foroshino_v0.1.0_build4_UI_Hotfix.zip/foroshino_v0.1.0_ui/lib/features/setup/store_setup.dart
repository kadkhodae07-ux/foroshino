import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../app/widgets.dart';

class StoreSetupScreen extends StatefulWidget {
  const StoreSetupScreen({super.key});

  @override
  State<StoreSetupScreen> createState() => _StoreSetupScreenState();
}

class _StoreSetupScreenState extends State<StoreSetupScreen> {
  int step = 0;
  String businessType = 'فروشگاه محلی';
  String currency = 'تومان';
  bool taxEnabled = false;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _StoreIdentityStep(
        businessType: businessType,
        onBusinessTypeChanged: (value) => setState(() => businessType = value),
      ),
      _StoreFinanceStep(
        currency: currency,
        taxEnabled: taxEnabled,
        onCurrencyChanged: (value) => setState(() => currency = value),
        onTaxChanged: (value) => setState(() => taxEnabled = value),
      ),
      const _StoreAppearanceStep(),
      const _StoreFinishStep(),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('راه‌اندازی فروشگاه')),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: Row(
                children: List.generate(
                  pages.length,
                  (index) => Expanded(
                    child: Container(
                      height: 5,
                      margin: EdgeInsets.only(left: index == pages.length - 1 ? 0 : 6),
                      decoration: BoxDecoration(
                        color: index <= step
                            ? Theme.of(context).colorScheme.primary
                            : Theme.of(context).colorScheme.outlineVariant,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: PageFrame(
                maxWidth: 760,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  child: KeyedSubtree(key: ValueKey(step), child: pages[step]),
                ),
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final isNarrow = constraints.maxWidth < 340;
                    final nextButton = FilledButton(
                      onPressed: () {
                        if (step < pages.length - 1) {
                          setState(() => step++);
                        } else {
                          context.go('/home');
                        }
                      },
                      child: Text(
                        step == pages.length - 1 ? 'مشاهده محیط فروشینو' : 'ادامه',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    );

                    if (step == 0) {
                      return SizedBox(width: double.infinity, child: nextButton);
                    }

                    final previousButton = OutlinedButton(
                      onPressed: () => setState(() => step--),
                      child: const Text('مرحله قبل'),
                    );

                    if (isNarrow) {
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(width: double.infinity, child: nextButton),
                          const SizedBox(height: 8),
                          SizedBox(width: double.infinity, child: previousButton),
                        ],
                      );
                    }

                    return Row(
                      children: [
                        Expanded(child: previousButton),
                        const SizedBox(width: 10),
                        Expanded(flex: 2, child: nextButton),
                      ],
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StoreIdentityStep extends StatelessWidget {
  const _StoreIdentityStep({
    required this.businessType,
    required this.onBusinessTypeChanged,
  });

  final String businessType;
  final ValueChanged<String> onBusinessTypeChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader(
          title: 'فروشگاهتان را معرفی کنید',
          subtitle: 'این اطلاعات در فاکتور و بخش مشخصات فروشگاه استفاده می‌شود.',
        ),
        const SizedBox(height: 20),
        AppCard(
          child: Column(
            children: [
              Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Icon(
                  Icons.add_a_photo_outlined,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
              const SizedBox(height: 18),
              const LabeledField(
                label: 'نام فروشگاه',
                hint: 'مثلاً فروشگاه بهار',
                icon: Icons.storefront_outlined,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: businessType,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'نوع کسب‌وکار',
                  prefixIcon: Icon(Icons.category_outlined),
                ),
                items: const [
                  'فروشگاه محلی',
                  'پوشاک',
                  'مواد غذایی',
                  'آرایشی و بهداشتی',
                  'فروش آنلاین',
                  'عمده‌فروشی کوچک',
                  'سایر',
                ].map((item) => DropdownMenuItem(
                      value: item,
                      child: Text(item, maxLines: 1, overflow: TextOverflow.ellipsis),
                    )).toList(),
                onChanged: (value) {
                  if (value != null) onBusinessTypeChanged(value);
                },
              ),
              const SizedBox(height: 16),
              const LabeledField(
                label: 'شماره تماس',
                hint: 'شماره تماس فروشگاه',
                icon: Icons.phone_outlined,
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 16),
              const LabeledField(
                label: 'نشانی',
                hint: 'نشانی کامل یا توضیح کوتاه',
                icon: Icons.location_on_outlined,
                maxLines: 2,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _StoreFinanceStep extends StatelessWidget {
  const _StoreFinanceStep({
    required this.currency,
    required this.taxEnabled,
    required this.onCurrencyChanged,
    required this.onTaxChanged,
  });

  final String currency;
  final bool taxEnabled;
  final ValueChanged<String> onCurrencyChanged;
  final ValueChanged<bool> onTaxChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader(
          title: 'تنظیمات مالی پایه',
          subtitle: 'این موارد بعداً از تنظیمات فروشگاه قابل تغییر هستند.',
        ),
        const SizedBox(height: 20),
        AppCard(
          child: Column(
            children: [
              DropdownButtonFormField<String>(
                initialValue: currency,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'واحد پول',
                  prefixIcon: Icon(Icons.payments_outlined),
                ),
                items: const ['تومان', 'ریال']
                    .map((item) => DropdownMenuItem(
                          value: item,
                          child: Text(item, maxLines: 1, overflow: TextOverflow.ellipsis),
                        ))
                    .toList(),
                onChanged: (value) {
                  if (value != null) onCurrencyChanged(value);
                },
              ),
              const SizedBox(height: 14),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: taxEnabled,
                onChanged: onTaxChanged,
                title: const Text('مالیات پیش‌فرض فعال باشد'),
                subtitle: const Text('در فرم فروش قابل تغییر خواهد بود'),
              ),
              if (taxEnabled) ...[
                const SizedBox(height: 8),
                const LabeledField(
                  label: 'درصد مالیات پیش‌فرض',
                  hint: 'مثلاً ۹',
                  icon: Icons.percent_rounded,
                  keyboardType: TextInputType.number,
                ),
              ],
              const SizedBox(height: 14),
              const LabeledField(
                label: 'پیشوند شماره فاکتور',
                hint: 'مثلاً FR',
                icon: Icons.numbers_rounded,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _StoreAppearanceStep extends StatefulWidget {
  const _StoreAppearanceStep();

  @override
  State<_StoreAppearanceStep> createState() => _StoreAppearanceStepState();
}

class _StoreAppearanceStepState extends State<_StoreAppearanceStep> {
  int selected = 0;

  @override
  Widget build(BuildContext context) {
    final colors = [
      const Color(0xFF0F766E),
      const Color(0xFF2563EB),
      const Color(0xFF7C3AED),
      const Color(0xFFBE123C),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader(
          title: 'ظاهر فروشگاه',
          subtitle: 'رنگ برند فقط در بخش‌های کلیدی استفاده می‌شود تا محیط شلوغ نشود.',
        ),
        const SizedBox(height: 20),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('رنگ اصلی', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 14),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: List.generate(colors.length, (index) {
                  final color = colors[index];
                  return InkWell(
                    onTap: () => setState(() => selected = index),
                    borderRadius: BorderRadius.circular(18),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: selected == index ? Colors.white : Colors.transparent,
                          width: 4,
                        ),
                        boxShadow: selected == index
                            ? [
                                BoxShadow(
                                  color: color.withValues(alpha: .28),
                                  blurRadius: 0,
                                  spreadRadius: 3,
                                ),
                              ]
                            : null,
                      ),
                      child: selected == index
                          ? const Icon(Icons.check_rounded, color: Colors.white)
                          : null,
                    ),
                  );
                }),
              ),
              const SizedBox(height: 24),
              const LabeledField(
                label: 'عنوان کوتاه روی فاکتور',
                hint: 'اختیاری',
                icon: Icons.short_text_rounded,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _StoreFinishStep extends StatelessWidget {
  const _StoreFinishStep();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader(
          title: 'فروشینو آماده است',
          subtitle: 'در نسخه ۰.۱، محیط کامل برنامه برای بررسی طراحی و تجربه کاربری فعال است.',
        ),
        const SizedBox(height: 20),
        AppCard(
          child: Column(
            children: [
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.check_rounded,
                  size: 46,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
              const SizedBox(height: 18),
              Text('تنظیمات اولیه تکمیل شد', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              Text(
                'هیچ داده تجاری ساختگی به حساب اضافه نمی‌شود. صفحه‌های خالی با پیام و اقدام مناسب نمایش داده خواهند شد.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const PreviewBanner(),
      ],
    );
  }
}
