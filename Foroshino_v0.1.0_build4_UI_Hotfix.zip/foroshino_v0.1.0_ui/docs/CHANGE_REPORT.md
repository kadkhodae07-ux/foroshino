# گزارش تغییرات نسخه ۰.۱.۰

## تکمیل‌شده

- ایجاد پروژه مستقل Flutter با معماری Feature-based
- افزودن Riverpod برای وضعیت تنظیمات UI
- افزودن GoRouter برای ناوبری ۵۰ مسیر
- ایجاد Design System مشترک و اجزای بازاستفاده‌پذیر
- طراحی صفحات عمومی، فروشگاهی و مدیریت کل
- افزودن Dark Mode و RTL
- افزودن الگوهای Empty/Loading/Offline/Warning/Success/Error
- تکمیل جریان‌های بصری محصول، بارکد، فروش، سفارش و فاکتور
- تکمیل جریان‌های بصری مشتری، پرداخت، موجودی، خرید، مرجوعی و هزینه
- تکمیل دستگاه‌های متصل و تنظیمات چاپگر
- حذف دکمه‌های مرده و اتصال آن‌ها به مسیر یا توضیح کنترل‌شده
- افزودن تست Smoke، Dark Mode و بازشدن مسیر مدیر با هفت لمس
- افزودن تست تمام مسیرها در عرض ۳۲۰ پیکسل و تست مسیرهای اصلی روی تبلت
- افزودن تولید خودکار ۱۴ اسکرین‌شات واقعی Flutter
- افزودن GitHub Actions برای Format، Static Validation، Analyze، Test، Screenshot و Build APK Debug

## پایگاه داده

بدون تغییر؛ پایگاه داده در نسخه ۰.۲ اضافه می‌شود.

## API

بدون تغییر؛ Backend و API در نسخه ۰.۵ اضافه می‌شود.

## فایل‌های اصلی

- `lib/app/*`
- `lib/features/*`
- `test/*`
- `android/*`
- `.github/workflows/foroshino-ui-build.yml`
- `tool/*`
- `docs/*`

## Build 4 hotfix — 2026-08-02

- Fixed the `/store-setup` layout at 320×640 by making dropdown contents expandable and footer actions adaptive.
- Replaced deprecated `DropdownButtonFormField.value` usage with `initialValue`.
- Added unique Hero tags to all retained floating action buttons in the indexed navigation shell.
- Preserved route-layout tests; no failing test was skipped or weakened.
- Updated application build number from `0.1.0+2` to `0.1.0+4`.


## Build 4 UI hotfix

- Removed the fixed 330-pixel product-empty-state viewport on the sales route so the shared empty-state component can use its natural responsive height.
- Replaced the fixed 180-pixel empty-cart viewport with a minimum-height constraint and centered wrapped text.
- Preserved the small-phone route test; no failing assertion was disabled or bypassed.
